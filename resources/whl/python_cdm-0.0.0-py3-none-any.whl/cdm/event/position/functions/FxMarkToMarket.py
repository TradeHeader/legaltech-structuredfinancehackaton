# pylint: disable=line-too-long, invalid-name, missing-function-docstring, missing-module-docstring, superfluous-parens
# pylint: disable=wrong-import-position, unused-import, unused-wildcard-import, wildcard-import, wrong-import-order, missing-class-docstring
from __future__ import annotations
import sys
import datetime
import inspect
from decimal import Decimal
from abc import ABC, abstractmethod
from rosetta.runtime.utils import *
from rosetta.runtime.func_proxy import replaceable, create_module_attr_guardian
from cdm.event.position.functions.InterpolateForwardRate import InterpolateForwardRate
from cdm.event.common.Trade import Trade
from cdm.base.math.functions.FilterQuantityByCurrency import FilterQuantityByCurrency

__all__ = ['FxMarkToMarket']



@replaceable
@calculation_func
def FxMarkToMarket(trade: Trade) -> Decimal:
    """
    Representation of sample mark to market calculation provided by a member firm.
    
    Parameters 
    ----------
    trade : Trade
    
    Returns
    -------
    value : number
    
    """
    _pre_registry = {}
    self = inspect.currentframe()
    
    # conditions
    
    @rosetta_local_condition(_pre_registry)
    def condition_0_ForwardPayoutExists(self):
        """
        The forwardPayout on the contract must exist.
        """
        return rosetta_attr_exists(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "trade"), "tradableProduct"), "product"), "contractualProduct"), "economicTerms"), "payout"), "forwardPayout"))
    # Execute all registered conditions
    execute_local_conditions(_pre_registry, 'Pre-condition')
    
    forwardPayout = get_only_element(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "trade"), "tradableProduct"), "product"), "contractualProduct"), "economicTerms"), "payout"), "forwardPayout"))
    quotedCurrency = get_only_element(set(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "trade"), "tradableProduct"), "tradeLot"), "priceQuantity"), "price"), "unit"), "currency")))
    baseCurrency = get_only_element(set(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "trade"), "tradableProduct"), "tradeLot"), "priceQuantity"), "price"), "perUnitOf"), "currency")))
    quantities = _resolve_rosetta_attr(_resolve_rosetta_attr(get_only_element(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "trade"), "tradableProduct"), "tradeLot")), "priceQuantity"), "quantity")
    quotedQuantity = _resolve_rosetta_attr(get_only_element(FilterQuantityByCurrency(_resolve_rosetta_attr(self, "quantities"), _resolve_rosetta_attr(self, "quotedCurrency"))), "value")
    baseQuantity = _resolve_rosetta_attr(get_only_element(FilterQuantityByCurrency(_resolve_rosetta_attr(self, "quantities"), _resolve_rosetta_attr(self, "baseCurrency"))), "value")
    interpolatedRate = InterpolateForwardRate(_resolve_rosetta_attr(self, "forwardPayout"))
    value =  (((_resolve_rosetta_attr(self, "quotedQuantity") / _resolve_rosetta_attr(self, "interpolatedRate")) - _resolve_rosetta_attr(self, "baseQuantity")) * _resolve_rosetta_attr(self, "interpolatedRate"))
    
    
    return value

sys.modules[__name__].__class__ = create_module_attr_guardian(sys.modules[__name__].__class__)

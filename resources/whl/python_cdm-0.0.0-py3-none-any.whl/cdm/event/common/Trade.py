# pylint: disable=line-too-long, invalid-name, missing-function-docstring
# pylint: disable=bad-indentation, trailing-whitespace, superfluous-parens
# pylint: disable=wrong-import-position, unused-import, unused-wildcard-import
# pylint: disable=wildcard-import, wrong-import-order, missing-class-docstring
# pylint: disable=missing-module-docstring
from __future__ import annotations
from typing import List, Optional
import datetime
import inspect
from decimal import Decimal
from pydantic import Field
from rosetta.runtime.utils import (
    BaseDataClass, rosetta_condition, _resolve_rosetta_attr
)
from rosetta.runtime.utils import *

__all__ = ['Trade']


class Trade(BaseDataClass):
  """
  Defines the output of a financial transaction between parties - a Business Event. A Trade impacts the financial position (i.e. the balance sheet) of involved parties.
  """
  
  tradeIdentifier: List[cdm.event.common.TradeIdentifier.TradeIdentifier] = Field([], description="Represents the identifier(s) that uniquely identify a trade for an identity issuer. A trade can include multiple identifiers, for example a trade that is reportable to both the CFTC and ESMA, and then has an associated USI (Unique Swap Identifier) UTI (Unique Trade Identifier).")
  
  """
  Represents the identifier(s) that uniquely identify a trade for an identity issuer. A trade can include multiple identifiers, for example a trade that is reportable to both the CFTC and ESMA, and then has an associated USI (Unique Swap Identifier) UTI (Unique Trade Identifier).
  """
  @rosetta_condition
  def cardinality_tradeIdentifier(self):
    return check_cardinality(self.tradeIdentifier, 1, None)
  
  
  tradeDate: AttributeWithMeta[datetime.date] | datetime.date = Field(..., description="Specifies the date which the trade was agreed.")
  
  """
  Specifies the date which the trade was agreed.
  """
  
  tradeTime: Optional[AttributeWithMeta[cdm.base.datetime.TimeZone.TimeZone] | cdm.base.datetime.TimeZone.TimeZone] = Field(None, description="Denotes the trade time and timezone as agreed by the parties to the trade.")
  
  """
  Denotes the trade time and timezone as agreed by the parties to the trade.
  """
  
  tradableProduct: cdm.product.template.TradableProduct.TradableProduct = Field(..., description="Represents the financial instrument The corresponding FpML construct is the product abstract element and the associated substitution group.")
  
  """
  Represents the financial instrument The corresponding FpML construct is the product abstract element and the associated substitution group.
  """
  
  party: List[cdm.base.staticdata.party.Party.Party] = Field([], description="Represents the parties to the trade. The cardinality is optional to address the case where the trade is defined within a BusinessEvent data type, in which case the party is specified in BusinessEvent.")
  
  """
  Represents the parties to the trade. The cardinality is optional to address the case where the trade is defined within a BusinessEvent data type, in which case the party is specified in BusinessEvent.
  """
  
  partyRole: List[cdm.base.staticdata.party.PartyRole.PartyRole] = Field([], description="Represents the role each specified party takes in the trade. further to the principal roles, payer and receiver.")
  
  """
  Represents the role each specified party takes in the trade. further to the principal roles, payer and receiver.
  """
  
  executionDetails: Optional[cdm.event.common.ExecutionDetails.ExecutionDetails] = Field(None, description="Represents information specific to trades that arose from executions.")
  
  """
  Represents information specific to trades that arose from executions.
  """
  
  contractDetails: Optional[cdm.event.common.ContractDetails.ContractDetails] = Field(None, description="Represents information specific to trades involving contractual products.")
  
  """
  Represents information specific to trades involving contractual products.
  """
  
  clearedDate: Optional[datetime.date] = Field(None, description="Specifies the date on which a trade is cleared (novated) through a central counterparty clearing service.")
  
  """
  Specifies the date on which a trade is cleared (novated) through a central counterparty clearing service.
  """
  
  collateral: Optional[cdm.product.collateral.Collateral.Collateral] = Field(None, description="Represents the collateral obligations of a party.")
  
  """
  Represents the collateral obligations of a party.
  """
  
  account: List[cdm.base.staticdata.party.Account.Account] = Field([], description="Represents a party's granular account information, which may be used in subsequent internal processing.")
  
  """
  Represents a party's granular account information, which may be used in subsequent internal processing.
  """
  
  @rosetta_condition
  def condition_0_SecurityPartyRoleBuyerSeller(self):
      """
      When the executed product is a security, both buyer and seller party roles must exist.
      """
      item = self
      def _then_fn0():
          return (contains(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "partyRole"), "role"), _resolve_rosetta_attr(PartyRoleEnum, "BUYER")) and contains(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "partyRole"), "role"), _resolve_rosetta_attr(PartyRoleEnum, "SELLER")))
      
      def _else_fn0():
          return True
      
      return if_cond_fn(rosetta_attr_exists(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "tradableProduct"), "product"), "security")), _then_fn0, _else_fn0)
  
  @rosetta_condition
  def condition_1_SecurityPrice(self):
      """
      When the executed product is a security, the price must be specified.
      """
      item = self
      def _then_fn0():
          return rosetta_attr_exists(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "tradableProduct"), "tradeLot"), "priceQuantity"), "price"))
      
      def _else_fn0():
          return True
      
      return if_cond_fn(rosetta_attr_exists(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "tradableProduct"), "product"), "security")), _then_fn0, _else_fn0)
  
  @rosetta_condition
  def condition_2_SettlementTerms(self):
      """
      When the executed product is a security, the settlement terms must be specified.
      """
      item = self
      def _then_fn0():
          return rosetta_attr_exists(_resolve_rosetta_attr(_resolve_rosetta_attr(get_only_element(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "tradableProduct"), "tradeLot")), "priceQuantity"), "settlementTerms"))
      
      def _else_fn0():
          return True
      
      return if_cond_fn(rosetta_attr_exists(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "tradableProduct"), "product"), "security")), _then_fn0, _else_fn0)
  
  @rosetta_condition
  def condition_3_PackageTrade(self):
      """
      When the trade is part of a package as specified in the execution details, the trade identifier must be found as one of the package components.
      """
      item = self
      def _then_fn0():
          return contains(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "executionDetails"), "packageReference"), "componentId"), "assignedIdentifier"), _resolve_rosetta_attr(_resolve_rosetta_attr(self, "tradeIdentifier"), "assignedIdentifier"))
      
      def _else_fn0():
          return True
      
      return if_cond_fn(rosetta_attr_exists(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "executionDetails"), "packageReference")), _then_fn0, _else_fn0)
  
  @rosetta_condition
  def condition_4_DeliverableObligationsPhysicalSettlementMatrix(self):
      """
      The below set of credit deliverable obligation provisions are specified as optional boolean in FpML and the CDM because they would be specified as part of the Physical Settlement Matrix when such document governs the contract terms. As a result, this data rule specifies that those provisions cannot be omitted if the Credit Derivatives Physical Settlement Matrix doesn't governs the terms of the contract.
      """
      item = self
      def _then_fn0():
          return ((((((((((((rosetta_attr_exists(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "tradableProduct"), "product"), "contractualProduct"), "economicTerms"), "payout"), "creditDefaultPayout"), "settlementTerms"), "physicalSettlementTerms"), "deliverableObligations"), "notSubordinated")) and rosetta_attr_exists(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "tradableProduct"), "product"), "contractualProduct"), "economicTerms"), "payout"), "creditDefaultPayout"), "settlementTerms"), "physicalSettlementTerms"), "deliverableObligations"), "specifiedCurrency"))) and rosetta_attr_exists(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "tradableProduct"), "product"), "contractualProduct"), "economicTerms"), "payout"), "creditDefaultPayout"), "settlementTerms"), "physicalSettlementTerms"), "deliverableObligations"), "notSovereignLender"))) and rosetta_attr_exists(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "tradableProduct"), "product"), "contractualProduct"), "economicTerms"), "payout"), "creditDefaultPayout"), "settlementTerms"), "physicalSettlementTerms"), "deliverableObligations"), "notDomesticCurrency"))) and rosetta_attr_exists(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "tradableProduct"), "product"), "contractualProduct"), "economicTerms"), "payout"), "creditDefaultPayout"), "settlementTerms"), "physicalSettlementTerms"), "deliverableObligations"), "notDomesticLaw"))) and rosetta_attr_exists(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "tradableProduct"), "product"), "contractualProduct"), "economicTerms"), "payout"), "creditDefaultPayout"), "settlementTerms"), "physicalSettlementTerms"), "deliverableObligations"), "notContingent"))) and rosetta_attr_exists(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "tradableProduct"), "product"), "contractualProduct"), "economicTerms"), "payout"), "creditDefaultPayout"), "settlementTerms"), "physicalSettlementTerms"), "deliverableObligations"), "notDomesticIssuance"))) and rosetta_attr_exists(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "tradableProduct"), "product"), "contractualProduct"), "economicTerms"), "payout"), "creditDefaultPayout"), "settlementTerms"), "physicalSettlementTerms"), "deliverableObligations"), "assignableLoan"))) and rosetta_attr_exists(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "tradableProduct"), "product"), "contractualProduct"), "economicTerms"), "payout"), "creditDefaultPayout"), "settlementTerms"), "physicalSettlementTerms"), "deliverableObligations"), "consentRequiredLoan"))) and rosetta_attr_exists(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "tradableProduct"), "product"), "contractualProduct"), "economicTerms"), "payout"), "creditDefaultPayout"), "settlementTerms"), "physicalSettlementTerms"), "deliverableObligations"), "transferable"))) and rosetta_attr_exists(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "tradableProduct"), "product"), "contractualProduct"), "economicTerms"), "payout"), "creditDefaultPayout"), "settlementTerms"), "physicalSettlementTerms"), "deliverableObligations"), "maximumMaturity"))) and rosetta_attr_exists(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "tradableProduct"), "product"), "contractualProduct"), "economicTerms"), "payout"), "creditDefaultPayout"), "settlementTerms"), "physicalSettlementTerms"), "deliverableObligations"), "notBearer"))) and ((rosetta_attr_exists(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "tradableProduct"), "product"), "contractualProduct"), "economicTerms"), "payout"), "creditDefaultPayout"), "settlementTerms"), "physicalSettlementTerms"), "deliverableObligations"), "fullFaithAndCreditObLiability")) or rosetta_attr_exists(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "tradableProduct"), "product"), "contractualProduct"), "economicTerms"), "payout"), "creditDefaultPayout"), "settlementTerms"), "physicalSettlementTerms"), "deliverableObligations"), "generalFundObligationLiability"))) or rosetta_attr_exists(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "tradableProduct"), "product"), "contractualProduct"), "economicTerms"), "payout"), "creditDefaultPayout"), "settlementTerms"), "physicalSettlementTerms"), "deliverableObligations"), "revenueObligationLiability"))))
      
      def _else_fn0():
          return True
      
      return if_cond_fn(((any_elements(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "contractDetails"), "documentation"), "legalAgreementIdentification"), "agreementName"), "contractualMatrix"), "matrixType"), "<>", _resolve_rosetta_attr(MatrixTypeEnum, "CREDIT_DERIVATIVES_PHYSICAL_SETTLEMENT_MATRIX")) or (not rosetta_attr_exists(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "contractDetails"), "documentation"), "legalAgreementIdentification"), "agreementName"), "contractualMatrix"), "matrixType")))) and rosetta_attr_exists(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "tradableProduct"), "product"), "contractualProduct"), "economicTerms"), "payout"), "creditDefaultPayout"), "settlementTerms"), "physicalSettlementTerms"), "deliverableObligations"))), _then_fn0, _else_fn0)
  
  @rosetta_condition
  def condition_5_ObligationsPhysicalSettlementMatrix(self):
      """
      The below set of obligation of the reference entity are specified as optional boolean in FpML and the CDM because they would be specified as part of the Physical Settlement Matrix when such document governs the contract terms. As a result, this data rule specifies that those provisions cannot be omitted if the Physical Settlement Matrix governs the terms of the contract. This data rule also applies to cash settled contracts because those could still end-up being physically settled, in case the case where an auction could not take place because of, say, liquidity considerations.
      """
      item = self
      def _then_fn0():
          return ((((rosetta_attr_exists(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "tradableProduct"), "product"), "contractualProduct"), "economicTerms"), "payout"), "creditDefaultPayout"), "protectionTerms"), "obligations"), "notSubordinated")) and rosetta_attr_exists(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "tradableProduct"), "product"), "contractualProduct"), "economicTerms"), "payout"), "creditDefaultPayout"), "protectionTerms"), "obligations"), "notSovereignLender"))) and rosetta_attr_exists(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "tradableProduct"), "product"), "contractualProduct"), "economicTerms"), "payout"), "creditDefaultPayout"), "protectionTerms"), "obligations"), "notDomesticLaw"))) and rosetta_attr_exists(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "tradableProduct"), "product"), "contractualProduct"), "economicTerms"), "payout"), "creditDefaultPayout"), "protectionTerms"), "obligations"), "notDomesticIssuance"))) and ((rosetta_attr_exists(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "tradableProduct"), "product"), "contractualProduct"), "economicTerms"), "payout"), "creditDefaultPayout"), "protectionTerms"), "obligations"), "fullFaithAndCreditObLiability")) or rosetta_attr_exists(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "tradableProduct"), "product"), "contractualProduct"), "economicTerms"), "payout"), "creditDefaultPayout"), "protectionTerms"), "obligations"), "generalFundObligationLiability"))) or rosetta_attr_exists(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "tradableProduct"), "product"), "contractualProduct"), "economicTerms"), "payout"), "creditDefaultPayout"), "protectionTerms"), "obligations"), "revenueObligationLiability"))))
      
      def _else_fn0():
          return True
      
      return if_cond_fn(((any_elements(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "contractDetails"), "documentation"), "legalAgreementIdentification"), "agreementName"), "contractualMatrix"), "matrixType"), "<>", _resolve_rosetta_attr(MatrixTypeEnum, "CREDIT_DERIVATIVES_PHYSICAL_SETTLEMENT_MATRIX")) or (not rosetta_attr_exists(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "contractDetails"), "documentation"), "legalAgreementIdentification"), "agreementName"), "contractualMatrix"), "matrixType")))) and rosetta_attr_exists(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "tradableProduct"), "product"), "contractualProduct"), "economicTerms"), "payout"), "creditDefaultPayout"), "protectionTerms"), "obligations"))), _then_fn0, _else_fn0)
  
  @rosetta_condition
  def condition_6_CreditEventsPhysicalSettlementMatrix(self):
      """
      The below set of credit events are specified as optional boolean in FpML and the CDM because they would be specified as part of the Physical Settlement Matrix when such document governs the contract terms. As a result, this data rule specifies that those provisions can only be omitted if the Physical Settlement Matrix governs the terms of the contract. This data rule also applies to cash settled contracts because those could still end-up being physically settled, in the case where an auction could not take place because of, say, liquidity considerations.
      """
      item = self
      def _then_fn0():
          return ((((rosetta_attr_exists(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "tradableProduct"), "product"), "contractualProduct"), "economicTerms"), "payout"), "creditDefaultPayout"), "protectionTerms"), "creditEvents"), "bankruptcy")) and rosetta_attr_exists(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "tradableProduct"), "product"), "contractualProduct"), "economicTerms"), "payout"), "creditDefaultPayout"), "protectionTerms"), "creditEvents"), "obligationDefault"))) and rosetta_attr_exists(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "tradableProduct"), "product"), "contractualProduct"), "economicTerms"), "payout"), "creditDefaultPayout"), "protectionTerms"), "creditEvents"), "obligationAcceleration"))) and rosetta_attr_exists(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "tradableProduct"), "product"), "contractualProduct"), "economicTerms"), "payout"), "creditDefaultPayout"), "protectionTerms"), "creditEvents"), "repudiationMoratorium"))) and rosetta_attr_exists(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "tradableProduct"), "product"), "contractualProduct"), "economicTerms"), "payout"), "creditDefaultPayout"), "protectionTerms"), "creditEvents"), "governmentalIntervention")))
      
      def _else_fn0():
          return True
      
      return if_cond_fn(((any_elements(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "contractDetails"), "documentation"), "legalAgreementIdentification"), "agreementName"), "contractualMatrix"), "matrixType"), "<>", _resolve_rosetta_attr(MatrixTypeEnum, "CREDIT_DERIVATIVES_PHYSICAL_SETTLEMENT_MATRIX")) or (not rosetta_attr_exists(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "contractDetails"), "documentation"), "legalAgreementIdentification"), "agreementName"), "contractualMatrix"), "matrixType")))) and rosetta_attr_exists(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "tradableProduct"), "product"), "contractualProduct"), "economicTerms"), "payout"), "creditDefaultPayout"), "protectionTerms"), "creditEvents"))), _then_fn0, _else_fn0)
  
  @rosetta_condition
  def condition_7_RestructuringPhysicalSettlementMatrix(self):
      """
      The below multiple holder obligation restructuring provisions is specified as optional boolean in FpML and the CDM because they would be specified as part of the Physical Settlement Matrix when such document governs the contract terms. As a result, this data rule specifies that this provision can only be omitted if the Physical Settlement Matrix governs the terms of the contract. This data rule also applies to cash settled contracts because those could still end-up being physically settled, in the case where an auction could not take place because of, say, liquidity considerations.
      """
      item = self
      def _then_fn0():
          return rosetta_attr_exists(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "tradableProduct"), "product"), "contractualProduct"), "economicTerms"), "payout"), "creditDefaultPayout"), "protectionTerms"), "creditEvents"), "restructuring"), "multipleHolderObligation"))
      
      def _else_fn0():
          return True
      
      return if_cond_fn(((any_elements(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "contractDetails"), "documentation"), "legalAgreementIdentification"), "agreementName"), "contractualMatrix"), "matrixType"), "<>", _resolve_rosetta_attr(MatrixTypeEnum, "CREDIT_DERIVATIVES_PHYSICAL_SETTLEMENT_MATRIX")) or (not rosetta_attr_exists(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "contractDetails"), "documentation"), "legalAgreementIdentification"), "agreementName"), "contractualMatrix"), "matrixType")))) and rosetta_attr_exists(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "tradableProduct"), "product"), "contractualProduct"), "economicTerms"), "payout"), "creditDefaultPayout"), "protectionTerms"), "creditEvents"), "restructuring"))), _then_fn0, _else_fn0)
  
  @rosetta_condition
  def condition_8_AdditionalFixedPaymentsMortgages(self):
      """
      The below set of additional fixed payment provisions are specified as optional boolean in FpML and the CDM because they only apply to mortgage credit default swaps. As a result, this data rule specifies that those provisions are required if the contract corresponds to a mortgage credit default swap. The provision related to the existence of the Contractual Term Supplement is meant to address the case where the underlier is a mortgage index.
      """
      item = self
      def _then_fn0():
          return ((rosetta_attr_exists(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "tradableProduct"), "product"), "contractualProduct"), "economicTerms"), "payout"), "creditDefaultPayout"), "protectionTerms"), "floatingAmountEvents"), "additionalFixedPayments"), "interestShortfallReimbursement")) and rosetta_attr_exists(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "tradableProduct"), "product"), "contractualProduct"), "economicTerms"), "payout"), "creditDefaultPayout"), "protectionTerms"), "floatingAmountEvents"), "additionalFixedPayments"), "principalShortfallReimbursement"))) and rosetta_attr_exists(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "tradableProduct"), "product"), "contractualProduct"), "economicTerms"), "payout"), "creditDefaultPayout"), "protectionTerms"), "floatingAmountEvents"), "additionalFixedPayments"), "writedownReimbursement")))
      
      def _else_fn0():
          return True
      
      return if_cond_fn((((all_elements(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "tradableProduct"), "product"), "contractualProduct"), "economicTerms"), "payout"), "creditDefaultPayout"), "generalTerms"), "referenceInformation"), "referenceObligation"), "security"), "securityType"), "=", _resolve_rosetta_attr(SecurityTypeEnum, "DEBT")) and all_elements(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "tradableProduct"), "product"), "contractualProduct"), "economicTerms"), "payout"), "creditDefaultPayout"), "generalTerms"), "referenceInformation"), "referenceObligation"), "security"), "debtType"), "debtClass"), "=", _resolve_rosetta_attr(DebtClassEnum, "ASSET_BACKED"))) or contains(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "contractDetails"), "documentation"), "legalAgreementIdentification"), "agreementName"), "contractualTermsSupplement"), "contractualTermsSupplementType"), _resolve_rosetta_attr(ContractualSupplementTypeEnum, "CD_SON_MBS"))) and rosetta_attr_exists(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "tradableProduct"), "product"), "contractualProduct"), "economicTerms"), "payout"), "creditDefaultPayout"), "protectionTerms"), "floatingAmountEvents"))), _then_fn0, _else_fn0)
  
  @rosetta_condition
  def condition_9_FloatingAmountEventsMortgages(self):
      """
      The below set of floating amount events provisions are specified as optional boolean in FpML and the CDM because they only apply to mortgage credit default swaps. As a result, this data rule specifies that those provisions are required if the contract corresponds to a mortgage credit default swap. The provision related to the existence of the Contractual Term Supplement is meant to address the case where the underlier is a mortgage index.
      """
      item = self
      def _then_fn0():
          return ((rosetta_attr_exists(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "tradableProduct"), "product"), "contractualProduct"), "economicTerms"), "payout"), "creditDefaultPayout"), "protectionTerms"), "floatingAmountEvents"), "failureToPayPrincipal")) and rosetta_attr_exists(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "tradableProduct"), "product"), "contractualProduct"), "economicTerms"), "payout"), "creditDefaultPayout"), "protectionTerms"), "floatingAmountEvents"), "writedown"))) and rosetta_attr_exists(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "tradableProduct"), "product"), "contractualProduct"), "economicTerms"), "payout"), "creditDefaultPayout"), "protectionTerms"), "floatingAmountEvents"), "impliedWritedown")))
      
      def _else_fn0():
          return True
      
      return if_cond_fn((((all_elements(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "tradableProduct"), "product"), "contractualProduct"), "economicTerms"), "payout"), "creditDefaultPayout"), "generalTerms"), "referenceInformation"), "referenceObligation"), "security"), "securityType"), "=", _resolve_rosetta_attr(SecurityTypeEnum, "DEBT")) and all_elements(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "tradableProduct"), "product"), "contractualProduct"), "economicTerms"), "payout"), "creditDefaultPayout"), "generalTerms"), "referenceInformation"), "referenceObligation"), "security"), "debtType"), "debtClass"), "=", _resolve_rosetta_attr(DebtClassEnum, "ASSET_BACKED"))) or contains(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "contractDetails"), "documentation"), "legalAgreementIdentification"), "agreementName"), "contractualTermsSupplement"), "contractualTermsSupplementType"), _resolve_rosetta_attr(ContractualSupplementTypeEnum, "CD_SON_MBS"))) and rosetta_attr_exists(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "tradableProduct"), "product"), "contractualProduct"), "economicTerms"), "payout"), "creditDefaultPayout"), "protectionTerms"), "floatingAmountEvents"))), _then_fn0, _else_fn0)
  
  @rosetta_condition
  def condition_10_CreditEventsMortgages(self):
      """
      The below set of credit events provisions are specified as optional boolean in FpML and the CDM because they only apply to mortgage credit default swaps. As a result, this data rule specifies that those provisions are required if the contract corresponds to a mortgage credit default swap. The provision related to the existence of the Contractual Term Supplement is meant to address the case where the underlier is a mortgage index.
      """
      item = self
      def _then_fn0():
          return (((((rosetta_attr_exists(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "tradableProduct"), "product"), "contractualProduct"), "economicTerms"), "payout"), "creditDefaultPayout"), "protectionTerms"), "creditEvents"), "failureToPayPrincipal")) and rosetta_attr_exists(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "tradableProduct"), "product"), "contractualProduct"), "economicTerms"), "payout"), "creditDefaultPayout"), "protectionTerms"), "creditEvents"), "failureToPayInterest"))) and rosetta_attr_exists(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "tradableProduct"), "product"), "contractualProduct"), "economicTerms"), "payout"), "creditDefaultPayout"), "protectionTerms"), "creditEvents"), "distressedRatingsDowngrade"))) and rosetta_attr_exists(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "tradableProduct"), "product"), "contractualProduct"), "economicTerms"), "payout"), "creditDefaultPayout"), "protectionTerms"), "creditEvents"), "maturityExtension"))) and rosetta_attr_exists(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "tradableProduct"), "product"), "contractualProduct"), "economicTerms"), "payout"), "creditDefaultPayout"), "protectionTerms"), "creditEvents"), "writedown"))) and rosetta_attr_exists(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "tradableProduct"), "product"), "contractualProduct"), "economicTerms"), "payout"), "creditDefaultPayout"), "protectionTerms"), "creditEvents"), "impliedWritedown")))
      
      def _else_fn0():
          return True
      
      return if_cond_fn((((all_elements(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "tradableProduct"), "product"), "contractualProduct"), "economicTerms"), "payout"), "creditDefaultPayout"), "generalTerms"), "referenceInformation"), "referenceObligation"), "security"), "securityType"), "=", _resolve_rosetta_attr(SecurityTypeEnum, "DEBT")) and all_elements(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "tradableProduct"), "product"), "contractualProduct"), "economicTerms"), "payout"), "creditDefaultPayout"), "generalTerms"), "referenceInformation"), "referenceObligation"), "security"), "debtType"), "debtClass"), "=", _resolve_rosetta_attr(DebtClassEnum, "ASSET_BACKED"))) or contains(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "contractDetails"), "documentation"), "legalAgreementIdentification"), "agreementName"), "contractualTermsSupplement"), "contractualTermsSupplementType"), _resolve_rosetta_attr(ContractualSupplementTypeEnum, "CD_SON_MBS"))) and rosetta_attr_exists(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "tradableProduct"), "product"), "contractualProduct"), "economicTerms"), "payout"), "creditDefaultPayout"), "protectionTerms"), "creditEvents"))), _then_fn0, _else_fn0)
  
  @rosetta_condition
  def condition_11_HedgingParty(self):
      """
      FpML specifies that there cannot be more than 2 hedging parties.
      """
      item = self
      def _then_fn0():
          return all_elements(rosetta_count(FilterPartyRole(_resolve_rosetta_attr(self, "partyRole"), _resolve_rosetta_attr(PartyRoleEnum, "HEDGING_PARTY"))), "<=", 2)
      
      def _else_fn0():
          return True
      
      return if_cond_fn(contains(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "partyRole"), "role"), _resolve_rosetta_attr(PartyRoleEnum, "HEDGING_PARTY")), _then_fn0, _else_fn0)
  
  @rosetta_condition
  def condition_12_DeterminingParty(self):
      """
      FpML specifies that there cannot be more than 2 determining parties.
      """
      item = self
      def _then_fn0():
          return all_elements(rosetta_count(FilterPartyRole(_resolve_rosetta_attr(self, "partyRole"), _resolve_rosetta_attr(PartyRoleEnum, "DETERMINING_PARTY"))), "<=", 2)
      
      def _else_fn0():
          return True
      
      return if_cond_fn(contains(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "partyRole"), "role"), _resolve_rosetta_attr(PartyRoleEnum, "DETERMINING_PARTY")), _then_fn0, _else_fn0)
  
  @rosetta_condition
  def condition_13_BarrierDerterminationAgent(self):
      """
      FpML specifies that there cannot be more than 1 barrier determination agent.
      """
      item = self
      def _then_fn0():
          return all_elements(rosetta_count(FilterPartyRole(_resolve_rosetta_attr(self, "partyRole"), _resolve_rosetta_attr(PartyRoleEnum, "BARRIER_DETERMINATION_AGENT"))), "<=", 1)
      
      def _else_fn0():
          return True
      
      return if_cond_fn(contains(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "partyRole"), "role"), _resolve_rosetta_attr(PartyRoleEnum, "BARRIER_DETERMINATION_AGENT")), _then_fn0, _else_fn0)
  
  @rosetta_condition
  def condition_14_ClearedDate(self):
      """
      If the cleared date exists, it needs to be on or after the trade date.
      """
      item = self
      def _then_fn0():
          return all_elements(_resolve_rosetta_attr(self, "clearedDate"), ">=", _resolve_rosetta_attr(self, "tradeDate"))
      
      def _else_fn0():
          return True
      
      return if_cond_fn(rosetta_attr_exists(_resolve_rosetta_attr(self, "clearedDate")), _then_fn0, _else_fn0)
  
  @rosetta_condition
  def condition_15_FpML_cd_1(self):
      """
      FpML validation rule cd-1 - If referenceInformation exists, tradeDate must be before effectiveDate/unadjustedDate.
      """
      item = self
      def _then_fn0():
          return (all_elements(_resolve_rosetta_attr(self, "tradeDate"), "<", _resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "tradableProduct"), "product"), "contractualProduct"), "economicTerms"), "effectiveDate"), "adjustableDate"), "unadjustedDate")) or all_elements(_resolve_rosetta_attr(self, "tradeDate"), "<", _resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "tradableProduct"), "product"), "contractualProduct"), "economicTerms"), "effectiveDate"), "adjustableDate"), "adjustedDate")))
      
      def _else_fn0():
          return True
      
      return if_cond_fn(rosetta_attr_exists(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "tradableProduct"), "product"), "contractualProduct"), "economicTerms"), "payout"), "creditDefaultPayout"), "generalTerms"), "referenceInformation")), _then_fn0, _else_fn0)
  
  @rosetta_condition
  def condition_16_FpML_cd_7(self):
      """
      FpML validation rule cd-7 - If condition LongForm is true, then effectiveDate/dateAdjustments exists.
      """
      item = self
      def _then_fn0():
          return (rosetta_attr_exists(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "tradableProduct"), "product"), "contractualProduct"), "economicTerms"), "payout"), "interestRatePayout"), "calculationPeriodDates"), "effectiveDate"), "adjustableDate"), "dateAdjustments")) or all_elements(_resolve_rosetta_attr(self, "tradeDate"), "<", _resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "tradableProduct"), "product"), "contractualProduct"), "economicTerms"), "effectiveDate"), "adjustableDate"), "adjustedDate")))
      
      def _else_fn0():
          return True
      
      return if_cond_fn((((not rosetta_attr_exists(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "contractDetails"), "documentation"), "legalAgreementIdentification"), "agreementName"), "masterConfirmationType"))) and (not rosetta_attr_exists(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "contractDetails"), "documentation"), "legalAgreementIdentification"), "agreementName"), "contractualMatrix")))) and rosetta_attr_exists(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "tradableProduct"), "product"), "contractualProduct"), "economicTerms"), "payout"), "creditDefaultPayout"), "generalTerms"), "referenceInformation"))), _then_fn0, _else_fn0)
  
  @rosetta_condition
  def condition_17_FpML_cd_8(self):
      """
      FpML validation rule cd-8 - If condition LongForm is true, and if scheduledTerminationDate exists then scheduledTerminationDate/dateAdjustments exists.
      """
      item = self
      def _then_fn0():
          return rosetta_attr_exists(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "tradableProduct"), "product"), "contractualProduct"), "economicTerms"), "terminationDate"), "adjustableDate"), "dateAdjustments"))
      
      def _else_fn0():
          return True
      
      return if_cond_fn((((not rosetta_attr_exists(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "contractDetails"), "documentation"), "legalAgreementIdentification"), "agreementName"), "masterConfirmationType"))) and (not rosetta_attr_exists(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "contractDetails"), "documentation"), "legalAgreementIdentification"), "agreementName"), "contractualMatrix")))) and rosetta_attr_exists(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "tradableProduct"), "product"), "contractualProduct"), "economicTerms"), "payout"), "creditDefaultPayout"), "generalTerms"), "referenceInformation"))), _then_fn0, _else_fn0)
  
  @rosetta_condition
  def condition_18_FpML_cd_11(self):
      """
      FpML validation rule cd-11 - If condition LongForm is true, and if condition ISDA2003 is true, then allGuarantees must exist.
      """
      item = self
      def _then_fn0():
          return rosetta_attr_exists(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "tradableProduct"), "product"), "contractualProduct"), "economicTerms"), "payout"), "creditDefaultPayout"), "generalTerms"), "referenceInformation"), "allGuarantees"))
      
      def _else_fn0():
          return True
      
      return if_cond_fn(((((not rosetta_attr_exists(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "contractDetails"), "documentation"), "legalAgreementIdentification"), "agreementName"), "masterConfirmationType"))) and (not rosetta_attr_exists(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "contractDetails"), "documentation"), "legalAgreementIdentification"), "agreementName"), "contractualMatrix")))) and rosetta_attr_exists(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "tradableProduct"), "product"), "contractualProduct"), "economicTerms"), "payout"), "creditDefaultPayout"), "generalTerms"), "referenceInformation"))) and all_elements(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "contractDetails"), "documentation"), "legalAgreementIdentification"), "agreementName"), "contractualDefinitionsType"), "=", _resolve_rosetta_attr(ContractualDefinitionsEnum, "ISDA_2003_CREDIT_DERIVATIVES"))), _then_fn0, _else_fn0)
  
  @rosetta_condition
  def condition_19_FpML_cd_19(self):
      """
      FpML validation rule cd-19 - If the condition ISDA1999Credit is true, then the following elements must not exist: protectionTerms/creditEvents/creditEventNotice/businessCenter, protectionTerms/creditEvents/restructuring/multipleHolderObligation, protectionTerms/creditEvents/restructuring/multipleCreditEventNotices, generalTerms/referenceInformation/allGuarantees, generalTerms/indexReferenceInformation, generalTerms/substitution, generalTerms/modifiedEquityDelivery.
      """
      item = self
      def _then_fn0():
          return (((((((not rosetta_attr_exists(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "tradableProduct"), "product"), "contractualProduct"), "economicTerms"), "payout"), "creditDefaultPayout"), "protectionTerms"), "creditEvents"), "creditEventNotice"), "businessCenter"))) and (not rosetta_attr_exists(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "tradableProduct"), "product"), "contractualProduct"), "economicTerms"), "payout"), "creditDefaultPayout"), "protectionTerms"), "creditEvents"), "restructuring"), "multipleHolderObligation")))) and (not rosetta_attr_exists(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "tradableProduct"), "product"), "contractualProduct"), "economicTerms"), "payout"), "creditDefaultPayout"), "protectionTerms"), "creditEvents"), "restructuring"), "multipleCreditEventNotices")))) and (not rosetta_attr_exists(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "tradableProduct"), "product"), "contractualProduct"), "economicTerms"), "payout"), "creditDefaultPayout"), "generalTerms"), "referenceInformation"), "allGuarantees")))) and (not rosetta_attr_exists(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "tradableProduct"), "product"), "contractualProduct"), "economicTerms"), "payout"), "creditDefaultPayout"), "generalTerms"), "indexReferenceInformation")))) and (not rosetta_attr_exists(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "tradableProduct"), "product"), "contractualProduct"), "economicTerms"), "payout"), "creditDefaultPayout"), "generalTerms"), "substitution")))) and (not rosetta_attr_exists(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "tradableProduct"), "product"), "contractualProduct"), "economicTerms"), "payout"), "creditDefaultPayout"), "generalTerms"), "modifiedEquityDelivery"))))
      
      def _else_fn0():
          return True
      
      return if_cond_fn(all_elements(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "contractDetails"), "documentation"), "legalAgreementIdentification"), "agreementName"), "contractualDefinitionsType"), "=", _resolve_rosetta_attr(ContractualDefinitionsEnum, "ISDA_1999_CREDIT_DERIVATIVES")), _then_fn0, _else_fn0)
  
  @rosetta_condition
  def condition_20_FpML_cd_20(self):
      """
      FpML validation rule cd-20 - If the condition ISDA2003 is true, then protectionTerms/obligations/notContingent must not exist.
      """
      item = self
      def _then_fn0():
          return (not rosetta_attr_exists(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "tradableProduct"), "product"), "contractualProduct"), "economicTerms"), "payout"), "creditDefaultPayout"), "protectionTerms"), "obligations"), "notContingent")))
      
      def _else_fn0():
          return True
      
      return if_cond_fn(all_elements(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "contractDetails"), "documentation"), "legalAgreementIdentification"), "agreementName"), "contractualDefinitionsType"), "=", _resolve_rosetta_attr(ContractualDefinitionsEnum, "ISDA_2003_CREDIT_DERIVATIVES")), _then_fn0, _else_fn0)
  
  @rosetta_condition
  def condition_21_FpML_cd_23(self):
      """
      FpML validation rule cd-23 - If the condition LongForm is true, then cashSettlementTerms or physicalSettlementTerms must exist.
      """
      item = self
      def _then_fn0():
          return (rosetta_attr_exists(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "tradableProduct"), "product"), "contractualProduct"), "economicTerms"), "payout"), "creditDefaultPayout"), "settlementTerms"), "cashSettlementTerms")) or rosetta_attr_exists(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "tradableProduct"), "product"), "contractualProduct"), "economicTerms"), "payout"), "creditDefaultPayout"), "settlementTerms"), "physicalSettlementTerms")))
      
      def _else_fn0():
          return True
      
      return if_cond_fn((((not rosetta_attr_exists(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "contractDetails"), "documentation"), "legalAgreementIdentification"), "agreementName"), "masterConfirmationType"))) and (not rosetta_attr_exists(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "contractDetails"), "documentation"), "legalAgreementIdentification"), "agreementName"), "contractualMatrix")))) and rosetta_attr_exists(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "tradableProduct"), "product"), "contractualProduct"), "economicTerms"), "payout"), "creditDefaultPayout"), "generalTerms"), "referenceInformation"))), _then_fn0, _else_fn0)
  
  @rosetta_condition
  def condition_22_FpML_cd_24(self):
      """
      FpML validation rule cd-24 - If the condition LongForm is true, then the following elements must exist: protectionTerms/creditEvents/creditEventNotice, protectionTerms/obligations, generalTerms/referenceInformation/referencePrice.
      """
      item = self
      def _then_fn0():
          return ((rosetta_attr_exists(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "tradableProduct"), "product"), "contractualProduct"), "economicTerms"), "payout"), "creditDefaultPayout"), "protectionTerms"), "creditEvents"), "creditEventNotice")) and rosetta_attr_exists(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "tradableProduct"), "product"), "contractualProduct"), "economicTerms"), "payout"), "creditDefaultPayout"), "protectionTerms"), "obligations"))) and rosetta_attr_exists(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "tradableProduct"), "product"), "contractualProduct"), "economicTerms"), "payout"), "creditDefaultPayout"), "generalTerms"), "referenceInformation"), "referencePrice")))
      
      def _else_fn0():
          return True
      
      return if_cond_fn((((not rosetta_attr_exists(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "contractDetails"), "documentation"), "legalAgreementIdentification"), "agreementName"), "masterConfirmationType"))) and (not rosetta_attr_exists(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "contractDetails"), "documentation"), "legalAgreementIdentification"), "agreementName"), "contractualMatrix")))) and rosetta_attr_exists(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "tradableProduct"), "product"), "contractualProduct"), "economicTerms"), "payout"), "creditDefaultPayout"), "generalTerms"), "referenceInformation"))), _then_fn0, _else_fn0)
  
  @rosetta_condition
  def condition_23_FpML_cd_25(self):
      """
      FpML validation rule cd-25 - If the condition LongForm is true, and if physicalSettlementTerms exists, then physicalSettlementTerms must contain settlementCurrency, physicalSettlementPeriod, escrow and deliverableObligations/accruedInterest.
      """
      item = self
      def _then_fn0():
          return (((rosetta_attr_exists(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "tradableProduct"), "product"), "contractualProduct"), "economicTerms"), "payout"), "creditDefaultPayout"), "settlementTerms"), "settlementCurrency")) and rosetta_attr_exists(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "tradableProduct"), "product"), "contractualProduct"), "economicTerms"), "payout"), "creditDefaultPayout"), "settlementTerms"), "physicalSettlementTerms"), "physicalSettlementPeriod"))) and rosetta_attr_exists(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "tradableProduct"), "product"), "contractualProduct"), "economicTerms"), "payout"), "creditDefaultPayout"), "settlementTerms"), "physicalSettlementTerms"), "escrow"))) and rosetta_attr_exists(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "tradableProduct"), "product"), "contractualProduct"), "economicTerms"), "payout"), "creditDefaultPayout"), "settlementTerms"), "physicalSettlementTerms"), "deliverableObligations"), "accruedInterest")))
      
      def _else_fn0():
          return True
      
      return if_cond_fn(((((not rosetta_attr_exists(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "contractDetails"), "documentation"), "legalAgreementIdentification"), "agreementName"), "masterConfirmationType"))) and (not rosetta_attr_exists(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "contractDetails"), "documentation"), "legalAgreementIdentification"), "agreementName"), "contractualMatrix")))) and rosetta_attr_exists(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "tradableProduct"), "product"), "contractualProduct"), "economicTerms"), "payout"), "creditDefaultPayout"), "generalTerms"), "referenceInformation"))) and rosetta_attr_exists(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "tradableProduct"), "product"), "contractualProduct"), "economicTerms"), "payout"), "creditDefaultPayout"), "settlementTerms"), "physicalSettlementTerms"))), _then_fn0, _else_fn0)
  
  @rosetta_condition
  def condition_24_FpML_cd_32(self):
      """
      FpML validation rule cd-32 - If condition LongForm is true, and if fixedAmountCalculation/calculationAmount exists, then fixedAmountCalculation/dayCountFraction must exist.
      """
      item = self
      def _then_fn0():
          return rosetta_attr_exists(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "tradableProduct"), "product"), "contractualProduct"), "economicTerms"), "payout"), "interestRatePayout"), "dayCountFraction"))
      
      def _else_fn0():
          return True
      
      return if_cond_fn((((((not rosetta_attr_exists(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "contractDetails"), "documentation"), "legalAgreementIdentification"), "agreementName"), "masterConfirmationType"))) and (not rosetta_attr_exists(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "contractDetails"), "documentation"), "legalAgreementIdentification"), "agreementName"), "contractualMatrix")))) and rosetta_attr_exists(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "tradableProduct"), "product"), "contractualProduct"), "economicTerms"), "payout"), "creditDefaultPayout"), "generalTerms"), "referenceInformation"))) and rosetta_attr_exists(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "tradableProduct"), "product"), "contractualProduct"), "economicTerms"), "payout"), "interestRatePayout"), "priceQuantity"))) and rosetta_attr_exists(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "tradableProduct"), "tradeLot"), "priceQuantity"), "quantity"), "value"))), _then_fn0, _else_fn0)
  
  @rosetta_condition
  def condition_25_FpML_ird_8(self):
      """
      FpML validation rule ird-8 - If the same party is specified as the payer and receiver, then different accounts must be specified.
      """
      item = self
      def _then_fn0():
          return all_elements(FpmlIrd8(_resolve_rosetta_attr(self, "tradableProduct"), _resolve_rosetta_attr(self, "account")), "=", False)
      
      def _else_fn0():
          return True
      
      return if_cond_fn(rosetta_attr_exists(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "tradableProduct"), "product"), "contractualProduct"), "economicTerms"), "payout"), "interestRatePayout")), _then_fn0, _else_fn0)
  
  @rosetta_condition
  def condition_26_ExtraordinaryEvents(self):
      """
      Extraordinary events provisions must be associated with an equity payout.
      """
      item = self
      def _then_fn0():
          return (rosetta_attr_exists(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "tradableProduct"), "product"), "contractualProduct"), "economicTerms"), "payout"), "performancePayout"), "returnTerms"), "priceReturnTerms")) or rosetta_attr_exists(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "tradableProduct"), "product"), "contractualProduct"), "economicTerms"), "payout"), "optionPayout"), "underlier"), "security")))
      
      def _else_fn0():
          return True
      
      return if_cond_fn(rosetta_attr_exists(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "contractDetails"), "documentation"), "agreementTerms"), "agreement"), "transactionAdditionalTerms"), "equityAdditionalTerms"), "extraordinaryEvents")), _then_fn0, _else_fn0)
  
  @rosetta_condition
  def condition_27_DisruptionEventsDeterminingParty(self):
      item = self
      def _then_fn1():
          return rosetta_attr_exists(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "contractDetails"), "documentation"), "agreementTerms"), "agreement"), "transactionAdditionalTerms"), "equityAdditionalTerms"), "extraordinaryEvents"), "additionalDisruptionEvents"), "determiningParty"))
      
      def _else_fn1():
          return True
      
      def _then_fn0():
          return (contains(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "tradableProduct"), "ancillaryParty"), "role"), _resolve_rosetta_attr(AncillaryRoleEnum, "DISRUPTION_EVENTS_DETERMINING_PARTY")) and if_cond_fn(contains(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "tradableProduct"), "ancillaryParty"), "role"), _resolve_rosetta_attr(AncillaryRoleEnum, "DISRUPTION_EVENTS_DETERMINING_PARTY")), _then_fn1, _else_fn1))
      
      def _else_fn0():
          return True
      
      return if_cond_fn(rosetta_attr_exists(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "contractDetails"), "documentation"), "agreementTerms"), "agreement"), "transactionAdditionalTerms"), "equityAdditionalTerms"), "extraordinaryEvents"), "additionalDisruptionEvents"), "determiningParty")), _then_fn0, _else_fn0)
  @metadata_key
  def validate_mkeys(__module__):
    return solve_metadata_key(__module__)

import cdm 
import cdm.event.common.TradeIdentifier
import cdm.base.datetime.TimeZone
import cdm.product.template.TradableProduct
import cdm.base.staticdata.party.Party
import cdm.base.staticdata.party.PartyRole
import cdm.event.common.ExecutionDetails
import cdm.event.common.ContractDetails
import cdm.product.collateral.Collateral
import cdm.base.staticdata.party.Account
from cdm.base.staticdata.party.PartyRoleEnum import PartyRoleEnum
from cdm.legaldocumentation.common.MatrixTypeEnum import MatrixTypeEnum
from cdm.base.staticdata.asset.common.SecurityTypeEnum import SecurityTypeEnum
from cdm.base.staticdata.asset.common.DebtClassEnum import DebtClassEnum
from cdm.legaldocumentation.common.ContractualSupplementTypeEnum import ContractualSupplementTypeEnum
from cdm.base.staticdata.party.functions.FilterPartyRole import FilterPartyRole
from cdm.legaldocumentation.common.ContractualDefinitionsEnum import ContractualDefinitionsEnum
from cdm.product.template.functions.FpmlIrd8 import FpmlIrd8
from cdm.base.staticdata.party.AncillaryRoleEnum import AncillaryRoleEnum

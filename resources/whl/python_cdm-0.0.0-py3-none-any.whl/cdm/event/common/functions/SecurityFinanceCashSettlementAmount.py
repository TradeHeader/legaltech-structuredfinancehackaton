# pylint: disable=line-too-long, invalid-name, missing-function-docstring, missing-module-docstring, superfluous-parens
# pylint: disable=wrong-import-position, unused-import, unused-wildcard-import, wildcard-import, wrong-import-order, missing-class-docstring
from __future__ import annotations
import sys
import datetime
import inspect
from decimal import Decimal
from abc import ABC, abstractmethod
from rosetta.runtime.utils import *
from rosetta.runtime.func_proxy import replaceable, create_module_attr_guardian
from cdm.event.common.Transfer import Transfer
from cdm.base.math.Quantity import Quantity
from cdm.base.staticdata.party.PayerReceiver import PayerReceiver
from cdm.event.common.TradeState import TradeState

__all__ = ['SecurityFinanceCashSettlementAmount']



@replaceable
def SecurityFinanceCashSettlementAmount(tradeState: TradeState, date: datetime.date, quantity: Quantity | None, payerReceiver: PayerReceiver | None) -> Transfer:
    """
    
    Parameters 
    ----------
    tradeState : TradeState
    
    date : date
    
    quantity : Quantity
    Specifies quantity amount returned if not the full amount from the TradeState, e.g. partial return
    
    payerReceiver : PayerReceiver
    
    Returns
    -------
    cashSettlementAmount : Transfer
    
    """
    _pre_registry = {}
    self = inspect.currentframe()
    
    # conditions
    
    @rosetta_local_condition(_pre_registry)
    def condition_0_ShareUnitExists(self):
        def _then_fn0():
            return all_elements(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "quantity"), "unit"), "financialUnit"), "=", _resolve_rosetta_attr(FinancialUnitEnum, "SHARE"))
        
        def _else_fn0():
            return True
        
        return if_cond_fn(rosetta_attr_exists(_resolve_rosetta_attr(self, "quantity")), _then_fn0, _else_fn0)
    
    @rosetta_local_condition(_pre_registry)
    def condition_1_ProductIdentifiersMatch(self):
        return all_elements(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "tradeState"), "trade"), "tradableProduct"), "tradeLot"), "priceQuantity"), "observable"), "productIdentifier"), "=", _resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "assetPayout"), "securityInformation"), "security"), "productIdentifier"))
    # Execute all registered conditions
    execute_local_conditions(_pre_registry, 'Pre-condition')
    
    def _then_fn0():
        return _resolve_rosetta_attr(self, "quantity")
    
    def _else_fn0():
        return FilterQuantityByFinancialUnit(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "tradeState"), "trade"), "tradableProduct"), "tradeLot"), "priceQuantity"), "quantity"), _resolve_rosetta_attr(FinancialUnitEnum, "SHARE"))
    
    def _then_fn2():
        return _resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(get_only_element(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "collateral"), "collateralProvisions"), "eligibleCollateral")), "treatment"), "valuationTreatment"), "marginPercentage")
    
    def _else_fn2():
        return 1.0
    
    def _then_fn1():
        return (1 / (1.0 - _resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(get_only_element(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "collateral"), "collateralProvisions"), "eligibleCollateral")), "treatment"), "valuationTreatment"), "haircutPercentage")))
    
    def _else_fn1():
        return if_cond_fn(rosetta_attr_exists(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(get_only_element(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "collateral"), "collateralProvisions"), "eligibleCollateral")), "treatment"), "valuationTreatment"), "marginPercentage")), _then_fn2, _else_fn2)
    
    def _then_fn3():
        return _resolve_rosetta_attr(ExtractCounterpartyByRole(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "tradeState"), "trade"), "tradableProduct"), "counterparty"), _resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "assetPayout"), "payerReceiver"), "receiver")), "partyReference")
    
    def _else_fn3():
        return True
    
    def _then_fn2():
        return _resolve_rosetta_attr(ExtractCounterpartyByRole(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "tradeState"), "trade"), "tradableProduct"), "counterparty"), _resolve_rosetta_attr(_resolve_rosetta_attr(self, "payerReceiver"), "receiver")), "partyReference")
    
    def _else_fn2():
        return if_cond_fn(rosetta_attr_exists(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "assetPayout"), "payerReceiver"), "receiver")), _then_fn3, _else_fn3)
    
    def _then_fn4():
        return _resolve_rosetta_attr(ExtractCounterpartyByRole(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "tradeState"), "trade"), "tradableProduct"), "counterparty"), _resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "assetPayout"), "payerReceiver"), "payer")), "partyReference")
    
    def _else_fn4():
        return True
    
    def _then_fn3():
        return _resolve_rosetta_attr(ExtractCounterpartyByRole(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "tradeState"), "trade"), "tradableProduct"), "counterparty"), _resolve_rosetta_attr(_resolve_rosetta_attr(self, "payerReceiver"), "payer")), "partyReference")
    
    def _else_fn3():
        return if_cond_fn(rosetta_attr_exists(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "assetPayout"), "payerReceiver"), "payer")), _then_fn4, _else_fn4)
    
    assetPayout = get_only_element(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "tradeState"), "trade"), "tradableProduct"), "product"), "contractualProduct"), "economicTerms"), "collateral"), "collateralPortfolio"), "collateralPosition"), "product"), "contractualProduct"), "economicTerms"), "payout"), "assetPayout"))
    collateral = _resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "tradeState"), "trade"), "tradableProduct"), "product"), "contractualProduct"), "economicTerms"), "collateral")
    securityQuantity = if_cond_fn(rosetta_attr_exists(_resolve_rosetta_attr(self, "quantity")), _then_fn0, _else_fn0)
    securityPrice = FilterPrice(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "tradeState"), "trade"), "tradableProduct"), "tradeLot"), "priceQuantity"), "price"), _resolve_rosetta_attr(PriceTypeEnum, "ASSET_PRICE"), [], [])
    marginRatio = if_cond_fn(rosetta_attr_exists(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(get_only_element(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "collateral"), "collateralProvisions"), "eligibleCollateral")), "treatment"), "valuationTreatment"), "haircutPercentage")), _then_fn1, _else_fn1)
    cashSettlementAmount = _get_rosetta_object('Transfer', 'quantity', _get_rosetta_object('NonNegativeQuantity', 'value', ((_resolve_rosetta_attr(_resolve_rosetta_attr(self, "securityPrice"), "value") * _resolve_rosetta_attr(_resolve_rosetta_attr(self, "securityQuantity"), "value")) * _resolve_rosetta_attr(self, "marginRatio"))))
    cashSettlementAmount = set_rosetta_attr(_resolve_rosetta_attr(self, 'cashSettlementAmount'), 'quantity->unit->currency', _resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "securityPrice"), "unit"), "currency"))
    cashSettlementAmount = set_rosetta_attr(_resolve_rosetta_attr(self, 'cashSettlementAmount'), 'payerReceiver->payerPartyReference', if_cond_fn(rosetta_attr_exists(_resolve_rosetta_attr(self, "payerReceiver")), _then_fn2, _else_fn2))
    cashSettlementAmount = set_rosetta_attr(_resolve_rosetta_attr(self, 'cashSettlementAmount'), 'payerReceiver->receiverPartyReference', if_cond_fn(rosetta_attr_exists(_resolve_rosetta_attr(self, "payerReceiver")), _then_fn3, _else_fn3))
    cashSettlementAmount = set_rosetta_attr(_resolve_rosetta_attr(self, 'cashSettlementAmount'), 'settlementDate->adjustedDate', _resolve_rosetta_attr(self, "date"))
    cashSettlementAmount = set_rosetta_attr(_resolve_rosetta_attr(self, 'cashSettlementAmount'), 'settlementOrigin->assetPayout', {_resolve_rosetta_attr(self, "assetPayout"): True})
    
    
    return cashSettlementAmount

sys.modules[__name__].__class__ = create_module_attr_guardian(sys.modules[__name__].__class__)

# pylint: disable=line-too-long, invalid-name, missing-function-docstring, missing-module-docstring, superfluous-parens
# pylint: disable=wrong-import-position, unused-import, unused-wildcard-import, wildcard-import, wrong-import-order, missing-class-docstring
from __future__ import annotations
import sys
import datetime
import inspect
from decimal import Decimal
from abc import ABC, abstractmethod
from rosetta.runtime.utils import *
from rosetta.runtime.func_proxy import replaceable, create_module_attr_guardian
from cdm.event.common.functions.UpdateIndexTransitionPriceAndRateOption import UpdateIndexTransitionPriceAndRateOption
from cdm.event.common.functions.FindMatchingIndexTransitionInstruction import FindMatchingIndexTransitionInstruction
from cdm.product.common.settlement.PriceQuantity import PriceQuantity
from cdm.event.common.TradeState import TradeState

__all__ = ['UpdateSpreadAdjustmentAndRateOptions']



@replaceable
def UpdateSpreadAdjustmentAndRateOptions(tradeState: TradeState, instructions: list[PriceQuantity]) -> TradeState:
    """
    For each of the trade state's price quantity, find a matching price quantity instruction, and call the update function.
    
    Parameters 
    ----------
    tradeState : TradeState
    Specifies the trade to be updated.
    
    instructions : PriceQuantity
    List of PriceQuantity from the IndexTransitionInstruction (e.g. one for each floating rate leg).
    
    Returns
    -------
    updatedTradeState : TradeState
    
    """
    self = inspect.currentframe()
    
    
    updatedTradeState =  _resolve_rosetta_attr(self, "tradeState")
    updatedTradeState = _get_rosetta_object('TradeState', 'trade', _get_rosetta_object('Trade', 'tradableProduct', _get_rosetta_object('TradableProduct', 'tradeLot', _get_rosetta_object('TradeLot', 'priceQuantity', map(lambda item: UpdateIndexTransitionPriceAndRateOption(item, FindMatchingIndexTransitionInstruction(_resolve_rosetta_attr(self, "instructions"), item)), _resolve_rosetta_attr(get_only_element(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "tradeState"), "trade"), "tradableProduct"), "tradeLot")), "priceQuantity"))))))
    
    
    return updatedTradeState

sys.modules[__name__].__class__ = create_module_attr_guardian(sys.modules[__name__].__class__)

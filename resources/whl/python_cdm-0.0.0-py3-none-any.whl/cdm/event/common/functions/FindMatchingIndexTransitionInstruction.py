# pylint: disable=line-too-long, invalid-name, missing-function-docstring, missing-module-docstring, superfluous-parens
# pylint: disable=wrong-import-position, unused-import, unused-wildcard-import, wildcard-import, wrong-import-order, missing-class-docstring
from __future__ import annotations
import sys
import datetime
import inspect
from decimal import Decimal
from abc import ABC, abstractmethod
from rosetta.runtime.utils import *
from rosetta.runtime.func_proxy import replaceable, create_module_attr_guardian
from cdm.product.common.settlement.PriceQuantity import PriceQuantity

__all__ = ['FindMatchingIndexTransitionInstruction']



@replaceable
def FindMatchingIndexTransitionInstruction(instructions: list[PriceQuantity], priceQuantity: PriceQuantity) -> PriceQuantity:
    """
    
    Parameters 
    ----------
    instructions : PriceQuantity
    
    priceQuantity : PriceQuantity
    
    Returns
    -------
    matchingInstruction : PriceQuantity
    
    """
    self = inspect.currentframe()
    
    
    matchingInstruction =  (lambda item: item[0])(rosetta_filter(_resolve_rosetta_attr(self, "instructions"), lambda item: ((all_elements(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "observable"), "rateOption"), "indexTenor"), "period"), "=", _resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "priceQuantity"), "observable"), "rateOption"), "indexTenor"), "period")) and all_elements(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "observable"), "rateOption"), "indexTenor"), "periodMultiplier"), "=", _resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "priceQuantity"), "observable"), "rateOption"), "indexTenor"), "periodMultiplier"))) and (all_elements(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "quantity"), "unit"), "currency"), "=", _resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "priceQuantity"), "quantity"), "unit"), "currency")) or all_elements(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "price"), "unit"), "currency"), "=", _resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "priceQuantity"), "price"), "unit"), "currency"))))))
    
    
    return matchingInstruction

sys.modules[__name__].__class__ = create_module_attr_guardian(sys.modules[__name__].__class__)

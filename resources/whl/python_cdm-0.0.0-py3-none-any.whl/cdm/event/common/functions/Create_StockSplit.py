# pylint: disable=line-too-long, invalid-name, missing-function-docstring, missing-module-docstring, superfluous-parens
# pylint: disable=wrong-import-position, unused-import, unused-wildcard-import, wildcard-import, wrong-import-order, missing-class-docstring
from __future__ import annotations
import sys
import datetime
import inspect
from decimal import Decimal
from abc import ABC, abstractmethod
from rosetta.runtime.utils import *
from rosetta.runtime.func_proxy import replaceable, create_module_attr_guardian
from cdm.base.math.UnitType import UnitType
from cdm.base.math.functions.FilterQuantityByFinancialUnit import FilterQuantityByFinancialUnit
from cdm.product.common.settlement.PriceQuantity import PriceQuantity
from cdm.event.common.QuantityChangeInstruction import QuantityChangeInstruction
from cdm.event.common.functions.Create_TradeState import Create_TradeState
from cdm.observable.asset.Price import Price
from cdm.base.math.FinancialUnitEnum import FinancialUnitEnum
from cdm.event.common.StockSplitInstruction import StockSplitInstruction
from cdm.event.common.TradeState import TradeState
from cdm.base.math.QuantityChangeDirectionEnum import QuantityChangeDirectionEnum
from cdm.event.common.PrimitiveInstruction import PrimitiveInstruction
from cdm.base.math.NonNegativeQuantitySchedule import NonNegativeQuantitySchedule

__all__ = ['Create_StockSplit']



@replaceable
def Create_StockSplit(stockSplitInstruction: StockSplitInstruction, before: TradeState) -> TradeState:
    """
    Function specification to create the fully-formed business event which represents the impact of a stock split (or a reverse stock split) on an Equity Derivatives contract on a certain date.
    
    Parameters 
    ----------
    stockSplitInstruction : StockSplitInstruction
    
    before : TradeState
    
    Returns
    -------
    after : TradeState
    
    """
    self = inspect.currentframe()
    
    
    preSplitNumberOfShares = _resolve_rosetta_attr(get_only_element(FilterQuantityByFinancialUnit(_resolve_rosetta_attr(_resolve_rosetta_attr(get_only_element(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "before"), "trade"), "tradableProduct"), "tradeLot")), "priceQuantity"), "quantity"), _resolve_rosetta_attr(FinancialUnitEnum, "SHARE"))), "value")
    postSplitNumberOfShares = NonNegativeQuantitySchedule(value=(_resolve_rosetta_attr(self, "preSplitNumberOfShares") * _resolve_rosetta_attr(_resolve_rosetta_attr(self, "stockSplitInstruction"), "adjustmentRatio")), unit=UnitType(financialUnit=_resolve_rosetta_attr(FinancialUnitEnum, "SHARE")))
    preSplitPrice = (lambda item: get_only_element(item))(rosetta_filter(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "before"), "trade"), "tradableProduct"), "tradeLot"), "priceQuantity"), "price"), lambda item: all_elements(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "perUnitOf"), "financialUnit"), "=", _resolve_rosetta_attr(FinancialUnitEnum, "SHARE"))))
    postSplitPrice = Price(value=(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "preSplitPrice"), "value") / _resolve_rosetta_attr(_resolve_rosetta_attr(self, "stockSplitInstruction"), "adjustmentRatio")), unit=_resolve_rosetta_attr(_resolve_rosetta_attr(self, "preSplitPrice"), "unit"), perUnitOf=_resolve_rosetta_attr(_resolve_rosetta_attr(self, "preSplitPrice"), "perUnitOf"), priceType=_resolve_rosetta_attr(_resolve_rosetta_attr(self, "preSplitPrice"), "priceType"), priceExpression=_resolve_rosetta_attr(_resolve_rosetta_attr(self, "preSplitPrice"), "priceExpression"), composite=_resolve_rosetta_attr(_resolve_rosetta_attr(self, "preSplitPrice"), "composite"), arithmeticOperator=_resolve_rosetta_attr(_resolve_rosetta_attr(self, "preSplitPrice"), "arithmeticOperator"), cashPrice=_resolve_rosetta_attr(_resolve_rosetta_attr(self, "preSplitPrice"), "cashPrice"), datedValue=[])
    postSplitPriceQuantity = PriceQuantity(price=_resolve_rosetta_attr(self, "postSplitPrice"), quantity=_resolve_rosetta_attr(self, "postSplitNumberOfShares"))
    quantityChangeInstruction = QuantityChangeInstruction(change=_resolve_rosetta_attr(self, "postSplitPriceQuantity"), direction=_resolve_rosetta_attr(QuantityChangeDirectionEnum, "REPLACE"), lotIdentifier=[])
    primitiveInstruction = PrimitiveInstruction(quantityChange=_resolve_rosetta_attr(self, "quantityChangeInstruction"))
    after =  Create_TradeState(_resolve_rosetta_attr(self, "primitiveInstruction"), _resolve_rosetta_attr(self, "before"))
    
    
    return after

sys.modules[__name__].__class__ = create_module_attr_guardian(sys.modules[__name__].__class__)

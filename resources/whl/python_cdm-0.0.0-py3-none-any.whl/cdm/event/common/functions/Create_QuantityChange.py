# pylint: disable=line-too-long, invalid-name, missing-function-docstring, missing-module-docstring, superfluous-parens
# pylint: disable=wrong-import-position, unused-import, unused-wildcard-import, wildcard-import, wrong-import-order, missing-class-docstring
from __future__ import annotations
import sys
import datetime
import inspect
from decimal import Decimal
from abc import ABC, abstractmethod
from rosetta.runtime.utils import *
from rosetta.runtime.func_proxy import replaceable, create_module_attr_guardian
from cdm.product.template.functions.FilterTradeLot import FilterTradeLot
from cdm.event.common.QuantityChangeInstruction import QuantityChangeInstruction
from cdm.product.template.TradableProduct import TradableProduct
from cdm.product.template.functions.AddTradeLot import AddTradeLot
from cdm.event.common.TradeState import TradeState
from cdm.product.common.settlement.functions.UpdateAmountForEachMatchingQuantity import UpdateAmountForEachMatchingQuantity
from cdm.product.template.TradeLot import TradeLot
from cdm.product.template.functions.MergeTradeLot import MergeTradeLot

__all__ = ['Create_QuantityChange']



@replaceable
def Create_QuantityChange(instruction: QuantityChangeInstruction, tradeState: TradeState) -> TradeState:
    """
    A specification of the inputs, outputs and constraints when calculating the after state of a Quantity Change Primitive Event
    
    Parameters 
    ----------
    instruction : QuantityChangeInstruction
    
    tradeState : TradeState
    
    Returns
    -------
    quantityChange : TradeState
    
    """
    _pre_registry = {}
    self = inspect.currentframe()
    
    # conditions
    
    @rosetta_local_condition(_pre_registry)
    def condition_0_CashPriceOnly(self):
        """
        Only termination where the termination price is specified as a cash price is supported for now.
        """
        def _then_fn0():
            return all_elements(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "instruction"), "change"), "price"), "priceType"), "=", _resolve_rosetta_attr(PriceTypeEnum, "CASH_PRICE"))
        
        def _else_fn0():
            return True
        
        return if_cond_fn((all_elements(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "instruction"), "direction"), "=", _resolve_rosetta_attr(QuantityChangeDirectionEnum, "DECREASE")) and rosetta_attr_exists(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "instruction"), "change"), "price"))), _then_fn0, _else_fn0)
    # Execute all registered conditions
    execute_local_conditions(_pre_registry, 'Pre-condition')
    
    def _then_fn1():
        return get_only_element(FilterTradeLot(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "tradableProduct"), "tradeLot"), _resolve_rosetta_attr(_resolve_rosetta_attr(self, "instruction"), "lotIdentifier")))
    
    def _else_fn1():
        return get_only_element(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "tradableProduct"), "tradeLot"))
    
    def _then_fn0():
        return if_cond_fn(rosetta_attr_exists(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "instruction"), "lotIdentifier")), _then_fn1, _else_fn1)
    
    def _else_fn0():
        return True
    
    def _then_fn1():
        return _resolve_rosetta_attr(_resolve_rosetta_attr(self, "instruction"), "change")
    
    def _else_fn1():
        return UpdateAmountForEachMatchingQuantity(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "tradeLot"), "priceQuantity"), _resolve_rosetta_attr(_resolve_rosetta_attr(self, "instruction"), "change"), _resolve_rosetta_attr(_resolve_rosetta_attr(self, "instruction"), "direction"))
    
    def _then_fn2():
        return _resolve_rosetta_attr(AddTradeLot(_resolve_rosetta_attr(self, "tradableProduct"), TradeLot(lotIdentifier=_resolve_rosetta_attr(_resolve_rosetta_attr(self, "instruction"), "lotIdentifier"), priceQuantity=_resolve_rosetta_attr(self, "newPriceQuantity"))), "tradeLot")
    
    def _else_fn2():
        return MergeTradeLot(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "tradableProduct"), "tradeLot"), TradeLot(lotIdentifier=_resolve_rosetta_attr(_resolve_rosetta_attr(self, "instruction"), "lotIdentifier"), priceQuantity=_resolve_rosetta_attr(self, "newPriceQuantity")))
    
    def _then_fn3():
        return _resolve_rosetta_attr(PositionStatusEnum, "CLOSED")
    
    def _else_fn3():
        return True
    
    tradableProduct = _resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "tradeState"), "trade"), "tradableProduct")
    tradeLot = if_cond_fn(any_elements(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "instruction"), "direction"), "<>", _resolve_rosetta_attr(QuantityChangeDirectionEnum, "INCREASE")), _then_fn0, _else_fn0)
    newPriceQuantity = if_cond_fn(all_elements(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "instruction"), "direction"), "=", _resolve_rosetta_attr(QuantityChangeDirectionEnum, "INCREASE")), _then_fn1, _else_fn1)
    newTradeLots = if_cond_fn(all_elements(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "instruction"), "direction"), "=", _resolve_rosetta_attr(QuantityChangeDirectionEnum, "INCREASE")), _then_fn2, _else_fn2)
    quantityChange =  _resolve_rosetta_attr(self, "tradeState")
    quantityChange = _get_rosetta_object('TradeState', 'trade', _get_rosetta_object('Trade', 'tradableProduct', TradableProduct(product=_resolve_rosetta_attr(_resolve_rosetta_attr(self, "tradableProduct"), "product"), tradeLot=_resolve_rosetta_attr(self, "newTradeLots"), counterparty=_resolve_rosetta_attr(_resolve_rosetta_attr(self, "tradableProduct"), "counterparty"), ancillaryParty=_resolve_rosetta_attr(_resolve_rosetta_attr(self, "tradableProduct"), "ancillaryParty"), adjustment=_resolve_rosetta_attr(_resolve_rosetta_attr(self, "tradableProduct"), "adjustment"))))
    quantityChange = set_rosetta_attr(_resolve_rosetta_attr(self, 'quantityChange'), 'state->positionState', if_cond_fn(all_elements(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "newTradeLots"), "priceQuantity"), "quantity"), "value"), "=", 0), _then_fn2, _else_fn2))
    
    
    return quantityChange

sys.modules[__name__].__class__ = create_module_attr_guardian(sys.modules[__name__].__class__)

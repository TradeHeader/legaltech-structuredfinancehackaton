# pylint: disable=line-too-long, invalid-name, missing-function-docstring, missing-module-docstring, superfluous-parens
# pylint: disable=wrong-import-position, unused-import, unused-wildcard-import, wildcard-import, wrong-import-order, missing-class-docstring
from __future__ import annotations
import sys
import datetime
import inspect
from decimal import Decimal
from abc import ABC, abstractmethod
from rosetta.runtime.utils import *
from rosetta.runtime.func_proxy import replaceable, create_module_attr_guardian
from cdm.event.common.Transfer import Transfer
from cdm.event.common.Reset import Reset
from cdm.event.common.TradeState import TradeState
from cdm.product.common.schedule.functions.CalculationPeriodRange import CalculationPeriodRange

__all__ = ['ResolveSecurityFinanceBillingAmount']



@replaceable
def ResolveSecurityFinanceBillingAmount(tradeState: TradeState, reset: Reset, recordStartDate: datetime.date, recordEndDate: datetime.date, transferDate: datetime.date) -> Transfer:
    """
    Calculates the billing amount for a Security Finance transaction.
    
    Parameters 
    ----------
    tradeState : TradeState
    
    reset : Reset
    
    recordStartDate : date
    
    recordEndDate : date
    
    transferDate : date
    
    Returns
    -------
    transfer : Transfer
    
    """
    self = inspect.currentframe()
    
    
    def _then_fn1():
        return _resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(get_only_element(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "collateral"), "collateralProvisions"), "eligibleCollateral")), "treatment"), "valuationTreatment"), "marginPercentage")
    
    def _else_fn1():
        return 1.0
    
    def _then_fn0():
        return _resolve_rosetta_attr(self, "valuationPercentage")
    
    def _else_fn0():
        return if_cond_fn(rosetta_attr_exists(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(get_only_element(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "collateral"), "collateralProvisions"), "eligibleCollateral")), "treatment"), "valuationTreatment"), "marginPercentage")), _then_fn1, _else_fn1)
    
    def _then_fn2():
        return FloatingAmount(_resolve_rosetta_attr(self, "interestRatePayout"), _resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "reset"), "resetValue"), "value"), _resolve_rosetta_attr(self, "billingQuantity"), _resolve_rosetta_attr(self, "recordEndDate"), _resolve_rosetta_attr(self, "calculationPeriodRange"))
    
    def _else_fn2():
        return True
    
    def _then_fn1():
        return FixedAmount(_resolve_rosetta_attr(self, "interestRatePayout"), _resolve_rosetta_attr(self, "billingQuantity"), _resolve_rosetta_attr(self, "recordEndDate"), _resolve_rosetta_attr(self, "calculationPeriodRange"))
    
    def _else_fn1():
        return if_cond_fn(rosetta_attr_exists(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "interestRatePayout"), "rateSpecification"), "floatingRate")), _then_fn2, _else_fn2)
    
    def _then_fn2():
        return _resolve_rosetta_attr(self, "payerPartyReference")
    
    def _else_fn2():
        return _resolve_rosetta_attr(self, "receiverPartyReference")
    
    def _then_fn3():
        return _resolve_rosetta_attr(self, "receiverPartyReference")
    
    def _else_fn3():
        return _resolve_rosetta_attr(self, "payerPartyReference")
    
    securityQuantity = FilterQuantityByFinancialUnit(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "tradeState"), "trade"), "tradableProduct"), "tradeLot"), "priceQuantity"), "quantity"), _resolve_rosetta_attr(FinancialUnitEnum, "SHARE"))
    interestRatePayout = get_only_element(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "tradeState"), "trade"), "tradableProduct"), "product"), "contractualProduct"), "economicTerms"), "payout"), "interestRatePayout"))
    assetPayout = get_only_element(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "tradeState"), "trade"), "tradableProduct"), "product"), "contractualProduct"), "economicTerms"), "collateral"), "collateralPortfolio"), "collateralPosition"), "product"), "contractualProduct"), "economicTerms"), "payout"), "assetPayout"))
    collateral = _resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "tradeState"), "trade"), "tradableProduct"), "product"), "contractualProduct"), "economicTerms"), "collateral")
    haircutPercentage = (1.0 - _resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(get_only_element(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "collateral"), "collateralProvisions"), "eligibleCollateral")), "treatment"), "valuationTreatment"), "haircutPercentage"))
    valuationPercentage = (1 / _resolve_rosetta_attr(self, "haircutPercentage"))
    marginRatio = if_cond_fn(rosetta_attr_exists(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(get_only_element(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "collateral"), "collateralProvisions"), "eligibleCollateral")), "treatment"), "valuationTreatment"), "haircutPercentage")), _then_fn0, _else_fn0)
    billingQuantity = ((_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "reset"), "resetValue"), "value") * _resolve_rosetta_attr(_resolve_rosetta_attr(self, "securityQuantity"), "value")) * _resolve_rosetta_attr(self, "marginRatio"))
    calculationPeriodRange = CalculationPeriodRange(_resolve_rosetta_attr(self, "recordStartDate"), _resolve_rosetta_attr(self, "recordEndDate"), [])
    performance = if_cond_fn(rosetta_attr_exists(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "interestRatePayout"), "rateSpecification"), "fixedRate")), _then_fn1, _else_fn1)
    payerPartyReference = _resolve_rosetta_attr(ExtractCounterpartyByRole(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "tradeState"), "trade"), "tradableProduct"), "counterparty"), _resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "interestRatePayout"), "payerReceiver"), "payer")), "partyReference")
    receiverPartyReference = _resolve_rosetta_attr(ExtractCounterpartyByRole(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "tradeState"), "trade"), "tradableProduct"), "counterparty"), _resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "interestRatePayout"), "payerReceiver"), "receiver")), "partyReference")
    transfer = _get_rosetta_object('Transfer', 'quantity', _get_rosetta_object('NonNegativeQuantity', 'value', _resolve_rosetta_attr(self, "performance")))
    transfer = set_rosetta_attr(_resolve_rosetta_attr(self, 'transfer'), 'quantity->unit->currency', _resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "interestRatePayout"), "priceQuantity"), "quantitySchedule"), "unit"), "currency"))
    transfer = set_rosetta_attr(_resolve_rosetta_attr(self, 'transfer'), 'payerReceiver->payerPartyReference', if_cond_fn(all_elements(_resolve_rosetta_attr(self, "performance"), ">=", 0), _then_fn0, _else_fn0))
    transfer = set_rosetta_attr(_resolve_rosetta_attr(self, 'transfer'), 'payerReceiver->receiverPartyReference', if_cond_fn(all_elements(_resolve_rosetta_attr(self, "performance"), ">=", 0), _then_fn1, _else_fn1))
    transfer = set_rosetta_attr(_resolve_rosetta_attr(self, 'transfer'), 'settlementDate->adjustedDate', _resolve_rosetta_attr(self, "transferDate"))
    
    
    return transfer

sys.modules[__name__].__class__ = create_module_attr_guardian(sys.modules[__name__].__class__)

# pylint: disable=line-too-long, invalid-name, missing-function-docstring, missing-module-docstring, superfluous-parens
# pylint: disable=wrong-import-position, unused-import, unused-wildcard-import, wildcard-import, wrong-import-order, missing-class-docstring
from __future__ import annotations
import sys
import datetime
import inspect
from decimal import Decimal
from abc import ABC, abstractmethod
from rosetta.runtime.utils import *
from rosetta.runtime.func_proxy import replaceable, create_module_attr_guardian
from cdm.event.common.TermsChangeInstruction import TermsChangeInstruction
from cdm.base.datetime.AdjustableOrRelativeDate import AdjustableOrRelativeDate
from cdm.product.template.ContractualProduct import ContractualProduct

__all__ = ['Create_RollTermChangeInstruction']



@replaceable
def Create_RollTermChangeInstruction(contractualProduct: ContractualProduct, effectiveRollDate: AdjustableOrRelativeDate, terminationDate: AdjustableOrRelativeDate) -> TermsChangeInstruction:
    """
    Creates the relevant terms change primitive instruction object for rolling a contractual product, which consists in the same terms as the original contractual product but with different effective and termination dates.
    
    Parameters 
    ----------
    contractualProduct : ContractualProduct
    The original contractual product to be rolled.
    
    effectiveRollDate : AdjustableOrRelativeDate
    The date to close and open a new position.
    
    terminationDate : AdjustableOrRelativeDate
    The new termination date.
    
    Returns
    -------
    termsChangeInstruction : TermsChangeInstruction
    
    """
    self = inspect.currentframe()
    
    
    termsChangeInstruction = _get_rosetta_object('TermsChangeInstruction', 'product', _get_rosetta_object('Product', 'contractualProduct', _resolve_rosetta_attr(self, "contractualProduct")))
    termsChangeInstruction = set_rosetta_attr(_resolve_rosetta_attr(self, 'termsChangeInstruction'), 'product->contractualProduct->economicTerms->effectiveDate', _resolve_rosetta_attr(self, "effectiveRollDate"))
    termsChangeInstruction = set_rosetta_attr(_resolve_rosetta_attr(self, 'termsChangeInstruction'), 'product->contractualProduct->economicTerms->terminationDate', _resolve_rosetta_attr(self, "terminationDate"))
    
    
    return termsChangeInstruction

sys.modules[__name__].__class__ = create_module_attr_guardian(sys.modules[__name__].__class__)

# pylint: disable=line-too-long, invalid-name, missing-function-docstring, missing-module-docstring, superfluous-parens
# pylint: disable=wrong-import-position, unused-import, unused-wildcard-import, wildcard-import, wrong-import-order, missing-class-docstring
from __future__ import annotations
import sys
import datetime
import inspect
from decimal import Decimal
from abc import ABC, abstractmethod
from rosetta.runtime.utils import *
from rosetta.runtime.func_proxy import replaceable, create_module_attr_guardian
from cdm.product.common.settlement.CashflowType import CashflowType
from cdm.observable.asset.Money import Money
from cdm.event.common.functions.Create_CashflowTermsChangeInstruction import Create_CashflowTermsChangeInstruction
from cdm.event.common.TradeState import TradeState
from cdm.event.common.PrimitiveInstruction import PrimitiveInstruction
from cdm.product.common.settlement.SettlementDate import SettlementDate
from cdm.event.common.functions.Create_Cashflow import Create_Cashflow
from cdm.product.common.settlement.ScheduledTransferEnum import ScheduledTransferEnum

__all__ = ['Create_OnDemandInterestPaymentPrimitiveInstruction']



@replaceable
def Create_OnDemandInterestPaymentPrimitiveInstruction(tradeState: TradeState, interestAmount: Money, settlementDate: SettlementDate) -> PrimitiveInstruction:
    """
    An instruction to make a interium interest payment by adding a payout leg to the deal.
    
    Parameters 
    ----------
    tradeState : TradeState
    The original trade to be modified.
    
    interestAmount : Money
    
    settlementDate : SettlementDate
    
    Returns
    -------
    instruction : PrimitiveInstruction
    
    """
    _pre_registry = {}
    self = inspect.currentframe()
    
    # conditions
    
    @rosetta_local_condition(_pre_registry)
    def condition_0_InterestRatePayoutExists(self):
        """
        Only a contractual product with a single interest rate payout can have an on-demand interest payment.
        """
        return rosetta_attr_exists(_resolve_rosetta_attr(self, "interestRatePayout"))
    
    @rosetta_local_condition(_pre_registry)
    def condition_1_Currency(self):
        """
        The currency of the interest amount must match the currency of the original interest rate payout.
        """
        return all_elements(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "interestAmount"), "unit"), "currency"), "=", _resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "interestRatePayout"), "priceQuantity"), "quantitySchedule"), "unit"), "currency"))
    # Execute all registered conditions
    execute_local_conditions(_pre_registry, 'Pre-condition')
    
    interestRatePayout = get_only_element(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "tradeState"), "trade"), "tradableProduct"), "product"), "contractualProduct"), "economicTerms"), "payout"), "interestRatePayout"))
    cashflow = Create_Cashflow(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "interestAmount"), "value"), _resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "interestRatePayout"), "priceQuantity"), "quantitySchedule"), "unit"), "currency"), _resolve_rosetta_attr(self, "settlementDate"), _resolve_rosetta_attr(_resolve_rosetta_attr(self, "interestRatePayout"), "payerReceiver"), CashflowType(cashflowType=_resolve_rosetta_attr(ScheduledTransferEnum, "NET_INTEREST")), [])
    instruction =  PrimitiveInstruction(termsChange=Create_CashflowTermsChangeInstruction(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "tradeState"), "trade"), "tradableProduct"), "product"), "contractualProduct"), _resolve_rosetta_attr(self, "cashflow")))
    
    
    return instruction

sys.modules[__name__].__class__ = create_module_attr_guardian(sys.modules[__name__].__class__)

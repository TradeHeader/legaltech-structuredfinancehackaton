# pylint: disable=line-too-long, invalid-name, missing-function-docstring, missing-module-docstring, superfluous-parens
# pylint: disable=wrong-import-position, unused-import, unused-wildcard-import, wildcard-import, wrong-import-order, missing-class-docstring
from __future__ import annotations
import sys
import datetime
import inspect
from decimal import Decimal
from abc import ABC, abstractmethod
from rosetta.runtime.utils import *
from rosetta.runtime.func_proxy import replaceable, create_module_attr_guardian
from cdm.event.common.BusinessEvent import BusinessEvent
from cdm.event.common.functions.ExtractBeforeEconomicTerms import ExtractBeforeEconomicTerms
from cdm.event.common.functions.ExtractBeforeTradableProduct import ExtractBeforeTradableProduct
from cdm.event.common.functions.ExtractAfterTradableProduct import ExtractAfterTradableProduct
from cdm.event.common.functions.ExtractOpenEconomicTerms import ExtractOpenEconomicTerms
from cdm.event.common.functions.ExtractTradeCollateralQuantity import ExtractTradeCollateralQuantity

__all__ = ['Qualify_PartialDelivery']



@replaceable
@qualification_func
def Qualify_PartialDelivery(businessEvent: BusinessEvent) -> bool:
    """
    Qualification of a partial delivery which constitutes a change in quantity and open with the remaining quantity and termination date.
    
    Parameters 
    ----------
    businessEvent : BusinessEvent
    
    Returns
    -------
    is_event : boolean
    
    """
    self = inspect.currentframe()
    
    
    beforeEconomicterms = ExtractBeforeEconomicTerms(_resolve_rosetta_attr(self, "businessEvent"))
    openEconomicTerms = ExtractOpenEconomicTerms(_resolve_rosetta_attr(self, "businessEvent"))
    openTrades = _resolve_rosetta_attr(FilterOpenTradeStates(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "businessEvent"), "after")), "trade")
    closedTradeState = FilterClosedTradeStates(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "businessEvent"), "after"))
    beforeTradableProduct = ExtractBeforeTradableProduct(_resolve_rosetta_attr(self, "businessEvent"))
    afterTradableProduct = ExtractAfterTradableProduct(_resolve_rosetta_attr(self, "businessEvent"))
    beforeTradeCollateralQuantity = ExtractTradeCollateralQuantity(_resolve_rosetta_attr(self, "beforeTradableProduct"))
    afterTradeCollateralQuantity = ExtractTradeCollateralQuantity(_resolve_rosetta_attr(self, "afterTradableProduct"))
    is_event =  ((((((((rosetta_attr_exists(_resolve_rosetta_attr(self, "beforeEconomicterms")) and rosetta_attr_exists(_resolve_rosetta_attr(self, "openEconomicTerms"))) and all_elements(rosetta_count(_resolve_rosetta_attr(self, "openTrades")), "=", 1)) and all_elements(rosetta_count(_resolve_rosetta_attr(self, "closedTradeState")), "=", 1)) and all_elements(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "openEconomicTerms"), "payout"), "interestRatePayout"), "=", _resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "beforeEconomicterms"), "payout"), "interestRatePayout"))) and all_elements(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "openEconomicTerms"), "collateral"), "=", _resolve_rosetta_attr(_resolve_rosetta_attr(self, "beforeEconomicterms"), "collateral"))) and all_elements(_resolve_rosetta_attr(self, "beforeTradeCollateralQuantity"), ">", _resolve_rosetta_attr(self, "afterTradeCollateralQuantity"))) and all_elements(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "openEconomicTerms"), "terminationDate"), "=", _resolve_rosetta_attr(_resolve_rosetta_attr(self, "beforeEconomicterms"), "terminationDate"))) and all_elements(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "openEconomicTerms"), "effectiveDate"), "=", _resolve_rosetta_attr(_resolve_rosetta_attr(self, "beforeEconomicterms"), "effectiveDate")))
    
    
    return is_event

sys.modules[__name__].__class__ = create_module_attr_guardian(sys.modules[__name__].__class__)

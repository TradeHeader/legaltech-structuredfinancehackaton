# pylint: disable=line-too-long, invalid-name, missing-function-docstring, missing-module-docstring, superfluous-parens
# pylint: disable=wrong-import-position, unused-import, unused-wildcard-import, wildcard-import, wrong-import-order, missing-class-docstring
from __future__ import annotations
import sys
import datetime
import inspect
from decimal import Decimal
from abc import ABC, abstractmethod
from rosetta.runtime.utils import *
from rosetta.runtime.func_proxy import replaceable, create_module_attr_guardian
from cdm.event.common.ExerciseInstruction import ExerciseInstruction
from cdm.event.common.functions.Create_Execution import Create_Execution
from cdm.event.common.TradeState import TradeState
from cdm.event.common.ExecutionInstruction import ExecutionInstruction

__all__ = ['Create_Exercise']



@replaceable
def Create_Exercise(exerciseInstruction: ExerciseInstruction, originalTrade: TradeState) -> TradeState:
    """
    Defines the process of putting into effect the rights specified in an options contract, such as to buy or sell a security.  Once exercised the option contract is terminated.
    
    Parameters 
    ----------
    exerciseInstruction : ExerciseInstruction
    Instruction containing the terms of the option exercise.
    
    originalTrade : TradeState
    The original trade to be split, which must be of single cardinality.
    
    Returns
    -------
    exercise : TradeState
    
    """
    _pre_registry = {}
    self = inspect.currentframe()
    
    # conditions
    
    @rosetta_local_condition(_pre_registry)
    def condition_0_OptionPayoutExists(self):
        """
        Requires that the original contract contains an option payout.
        """
        return rosetta_attr_exists(_resolve_rosetta_attr(self, "optionPayout"))
    # Execute all registered conditions
    execute_local_conditions(_pre_registry, 'Pre-condition')
    
    def _then_fn0():
        return _resolve_rosetta_attr(_resolve_rosetta_attr(self, "exerciseInstruction"), "exerciseOption")
    
    def _else_fn0():
        return get_only_element(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "tradableProduct"), "product"), "contractualProduct"), "economicTerms"), "payout"), "optionPayout"))
    
    tradableProduct = _resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "originalTrade"), "trade"), "tradableProduct")
    optionPayout = if_cond_fn(rosetta_attr_exists(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "exerciseInstruction"), "exerciseOption")), _then_fn0, _else_fn0)
    underlier = _resolve_rosetta_attr(_resolve_rosetta_attr(self, "optionPayout"), "underlier")
    execution = Create_Execution(ExecutionInstruction(product=_resolve_rosetta_attr(self, "underlier"), priceQuantity=_resolve_rosetta_attr(get_only_element(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "tradableProduct"), "tradeLot")), "priceQuantity"), counterparty=_resolve_rosetta_attr(_resolve_rosetta_attr(self, "tradableProduct"), "counterparty"), ancillaryParty=_resolve_rosetta_attr(_resolve_rosetta_attr(self, "tradableProduct"), "ancillaryParty"), parties=_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "originalTrade"), "trade"), "party"), partyRoles=_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "originalTrade"), "trade"), "partyRole"), executionDetails=[], tradeDate=_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "originalTrade"), "trade"), "tradeDate"), tradeIdentifier=_resolve_rosetta_attr(_resolve_rosetta_attr(self, "exerciseInstruction"), "replacementTradeIdentifier")))
    exercise = Create_TradeState(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "exerciseInstruction"), "exerciseQuantity"), _resolve_rosetta_attr(self, "originalTrade"))
    exercise.add_rosetta_attr(self, _resolve_rosetta_attr(self, "execution"))
    
    
    return exercise

sys.modules[__name__].__class__ = create_module_attr_guardian(sys.modules[__name__].__class__)

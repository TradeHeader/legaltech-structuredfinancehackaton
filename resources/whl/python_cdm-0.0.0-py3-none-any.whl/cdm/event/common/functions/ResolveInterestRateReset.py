# pylint: disable=line-too-long, invalid-name, missing-function-docstring, missing-module-docstring, superfluous-parens
# pylint: disable=wrong-import-position, unused-import, unused-wildcard-import, wildcard-import, wrong-import-order, missing-class-docstring
from __future__ import annotations
import sys
import datetime
import inspect
from decimal import Decimal
from abc import ABC, abstractmethod
from rosetta.runtime.utils import *
from rosetta.runtime.func_proxy import replaceable, create_module_attr_guardian
from cdm.product.asset.InterestRatePayout import InterestRatePayout
from cdm.observable.event.Observation import Observation
from cdm.event.common.Reset import Reset

__all__ = ['ResolveInterestRateReset']



@replaceable
def ResolveInterestRateReset(payouts: list[InterestRatePayout], observation: Observation, resetDate: datetime.date, rateRecordDate: datetime.date | None) -> Reset:
    """
    Defines how to resolve the reset value for an InterestRatePayout.
    
    Parameters 
    ----------
    payouts : InterestRatePayout
    
    observation : Observation
    
    resetDate : date
    
    rateRecordDate : date
    
    Returns
    -------
    reset : Reset
    
    """
    self = inspect.currentframe()
    
    
    reset = _get_rosetta_object('Reset', 'resetValue', _resolve_rosetta_attr(_resolve_rosetta_attr(self, "observation"), "observedValue"))
    reset = set_rosetta_attr(_resolve_rosetta_attr(self, 'reset'), 'resetDate', _resolve_rosetta_attr(self, "resetDate"))
    reset = set_rosetta_attr(_resolve_rosetta_attr(self, 'reset'), 'rateRecordDate', _resolve_rosetta_attr(self, "rateRecordDate"))
    reset.add_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, reset), 'observations'), _resolve_rosetta_attr(self, "observation"))
    
    
    return reset

sys.modules[__name__].__class__ = create_module_attr_guardian(sys.modules[__name__].__class__)

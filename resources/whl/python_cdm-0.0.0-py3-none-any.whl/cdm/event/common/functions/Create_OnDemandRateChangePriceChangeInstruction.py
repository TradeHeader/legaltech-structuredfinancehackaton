# pylint: disable=line-too-long, invalid-name, missing-function-docstring, missing-module-docstring, superfluous-parens
# pylint: disable=wrong-import-position, unused-import, unused-wildcard-import, wildcard-import, wrong-import-order, missing-class-docstring
from __future__ import annotations
import sys
import datetime
import inspect
from decimal import Decimal
from abc import ABC, abstractmethod
from rosetta.runtime.utils import *
from rosetta.runtime.func_proxy import replaceable, create_module_attr_guardian
from cdm.product.common.settlement.PriceQuantity import PriceQuantity
from cdm.event.common.QuantityChangeInstruction import QuantityChangeInstruction
from cdm.observable.asset.Price import Price

__all__ = ['Create_OnDemandRateChangePriceChangeInstruction']



@replaceable
def Create_OnDemandRateChangePriceChangeInstruction(priceQuantity: list[PriceQuantity], newRate: Decimal) -> QuantityChangeInstruction:
    """
    Creates a price change instruction for an on-demand rate change, based on a new rate provided as a single number by matching it to a single rate price.
    
    Parameters 
    ----------
    priceQuantity : PriceQuantity
    The original price / quantity to be modified with the new rate.
    
    newRate : number
    The new rate value, provided as a single number.
    
    Returns
    -------
    quantityChangeInstruction : QuantityChangeInstruction
    
    """
    _pre_registry = {}
    self = inspect.currentframe()
    
    # conditions
    
    @rosetta_local_condition(_pre_registry)
    def condition_0_OneRatePrice(self):
        """
        There should be 1 and only 1 rate type price in the current price.
        """
        return rosetta_attr_exists(_resolve_rosetta_attr(self, "currentRatePrice"))
    # Execute all registered conditions
    execute_local_conditions(_pre_registry, 'Pre-condition')
    
    currentRatePrice = (lambda item: get_only_element(item))((lambda item: rosetta_filter(item, lambda item: all_elements(_resolve_rosetta_attr(self, "priceType"), "=", _resolve_rosetta_attr(PriceTypeEnum, "INTEREST_RATE"))))((lambda item: flatten_list(item))(map(lambda item: _resolve_rosetta_attr(self, "price"), _resolve_rosetta_attr(self, "priceQuantity")))))
    newPrice = Price(value=_resolve_rosetta_attr(self, "newRate"), unit=_resolve_rosetta_attr(_resolve_rosetta_attr(self, "currentRatePrice"), "unit"), perUnitOf=_resolve_rosetta_attr(_resolve_rosetta_attr(self, "currentRatePrice"), "perUnitOf"), priceType=_resolve_rosetta_attr(_resolve_rosetta_attr(self, "currentRatePrice"), "priceType"), priceExpression=_resolve_rosetta_attr(_resolve_rosetta_attr(self, "currentRatePrice"), "priceExpression"), composite=_resolve_rosetta_attr(_resolve_rosetta_attr(self, "currentRatePrice"), "composite"), arithmeticOperator=_resolve_rosetta_attr(_resolve_rosetta_attr(self, "currentRatePrice"), "arithmeticOperator"), cashPrice=_resolve_rosetta_attr(_resolve_rosetta_attr(self, "currentRatePrice"), "cashPrice"), datedValue=[])
    newPriceQuantity = PriceQuantity(price=_resolve_rosetta_attr(self, "newPrice"))
    quantityChangeInstruction =  QuantityChangeInstruction(change=_resolve_rosetta_attr(self, "newPriceQuantity"), direction=_resolve_rosetta_attr(QuantityChangeDirectionEnum, "REPLACE"), lotIdentifier=[])
    
    
    return quantityChangeInstruction

sys.modules[__name__].__class__ = create_module_attr_guardian(sys.modules[__name__].__class__)

# pylint: disable=line-too-long, invalid-name, missing-function-docstring, missing-module-docstring, superfluous-parens
# pylint: disable=wrong-import-position, unused-import, unused-wildcard-import, wildcard-import, wrong-import-order, missing-class-docstring
from __future__ import annotations
import sys
import datetime
import inspect
from decimal import Decimal
from abc import ABC, abstractmethod
from rosetta.runtime.utils import *
from rosetta.runtime.func_proxy import replaceable, create_module_attr_guardian
from cdm.product.common.settlement.PriceQuantity import PriceQuantity
from cdm.event.common.QuantityChangeInstruction import QuantityChangeInstruction
from cdm.observable.asset.Price import Price
from cdm.event.common.TradeState import TradeState
from cdm.event.common.PrimitiveInstruction import PrimitiveInstruction
from cdm.base.datetime.AdjustableOrRelativeDate import AdjustableOrRelativeDate
from cdm.base.math.NonNegativeQuantitySchedule import NonNegativeQuantitySchedule
from cdm.event.common.functions.Create_EffectiveOrTerminationDateTermChangeInstruction import Create_EffectiveOrTerminationDateTermChangeInstruction

__all__ = ['Create_RepricePrimitiveInstruction']



@replaceable
def Create_RepricePrimitiveInstruction(tradeState: TradeState, newAllinPrice: Decimal, newCashValue: Decimal, effectiveRepriceDate: AdjustableOrRelativeDate) -> PrimitiveInstruction:
    """
    Creates the primitive instructions for a repricing that alters the cash amount of the trade. Transaction value and variation margin are processed separately as are transfers of cash and securities.
    
    Parameters 
    ----------
    tradeState : TradeState
    The original trade state and trade to be repriced.
    
    newAllinPrice : number
    The collateral new all-in price.
    
    newCashValue : number
    The new cash amount.
    
    effectiveRepriceDate : AdjustableOrRelativeDate
    The date to reprice the collateral
    
    Returns
    -------
    instruction : PrimitiveInstruction
    
    """
    self = inspect.currentframe()
    
    
    oldPriceQuantity = _resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "tradeState"), "trade"), "tradableProduct"), "tradeLot"), "priceQuantity")
    currentAssetPrice = (lambda item: get_only_element(item))((lambda item: rosetta_filter(item, lambda item: all_elements(_resolve_rosetta_attr(self, "priceType"), "=", _resolve_rosetta_attr(PriceTypeEnum, "ASSET_PRICE"))))((lambda item: flatten_list(item))(map(lambda item: _resolve_rosetta_attr(self, "price"), _resolve_rosetta_attr(self, "oldPriceQuantity")))))
    newPrice = Price(value=_resolve_rosetta_attr(self, "newAllinPrice"), unit=_resolve_rosetta_attr(_resolve_rosetta_attr(self, "currentAssetPrice"), "unit"), perUnitOf=_resolve_rosetta_attr(_resolve_rosetta_attr(self, "currentAssetPrice"), "perUnitOf"), priceType=_resolve_rosetta_attr(_resolve_rosetta_attr(self, "currentAssetPrice"), "priceType"), priceExpression=_resolve_rosetta_attr(_resolve_rosetta_attr(self, "currentAssetPrice"), "priceExpression"), composite=_resolve_rosetta_attr(_resolve_rosetta_attr(self, "currentAssetPrice"), "composite"), arithmeticOperator=_resolve_rosetta_attr(_resolve_rosetta_attr(self, "currentAssetPrice"), "arithmeticOperator"), cashPrice=_resolve_rosetta_attr(_resolve_rosetta_attr(self, "currentAssetPrice"), "cashPrice"), datedValue=[])
    changeCashQuantity = (lambda item: set(item))(map(lambda item: NonNegativeQuantitySchedule(value=_resolve_rosetta_attr(self, "newCashValue"), unit=_resolve_rosetta_attr(self, "unit")), _resolve_rosetta_attr(_resolve_rosetta_attr(get_only_element(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "tradeState"), "trade"), "tradableProduct"), "tradeLot")), "priceQuantity"), "quantity")))
    newPriceQuantity = PriceQuantity(price=[_resolve_rosetta_attr(self, "newPrice")], quantity=_resolve_rosetta_attr(self, "changeCashQuantity"))
    instruction = _get_rosetta_object('PrimitiveInstruction', 'split', _get_rosetta_object('SplitInstruction', 'breakdown', [Create_TerminationInstruction(_resolve_rosetta_attr(self, "tradeState"))]))
    instruction.add_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, instruction), 'split'), 'breakdown'), [PrimitiveInstruction(quantityChange=QuantityChangeInstruction(change=[_resolve_rosetta_attr(self, "newPriceQuantity")], direction=_resolve_rosetta_attr(QuantityChangeDirectionEnum, "REPLACE"), lotIdentifier=[]), termsChange=Create_EffectiveOrTerminationDateTermChangeInstruction(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "tradeState"), "trade"), "tradableProduct"), "product"), "contractualProduct"), _resolve_rosetta_attr(self, "effectiveRepriceDate"), []))])
    
    
    return instruction

sys.modules[__name__].__class__ = create_module_attr_guardian(sys.modules[__name__].__class__)

# pylint: disable=line-too-long, invalid-name, missing-function-docstring, missing-module-docstring, superfluous-parens
# pylint: disable=wrong-import-position, unused-import, unused-wildcard-import, wildcard-import, wrong-import-order, missing-class-docstring
from __future__ import annotations
import sys
import datetime
import inspect
from decimal import Decimal
from abc import ABC, abstractmethod
from rosetta.runtime.utils import *
from rosetta.runtime.func_proxy import replaceable, create_module_attr_guardian
from cdm.event.common.functions.FilterOpenTradeStates import FilterOpenTradeStates
from cdm.event.common.BusinessEvent import BusinessEvent
from cdm.event.common.functions.FilterClosedTradeStates import FilterClosedTradeStates

__all__ = ['Qualify_Roll']



@replaceable
@qualification_func
def Qualify_Roll(businessEvent: BusinessEvent) -> bool:
    """
    Qualification of a roll event based on: (i) terminating a single existing trade, (ii) entering into a new trade with the same details as the old trade, except for the effective and termination date where the effective date. The roll qualification does not make any assumption on the resulting quantity which may change compared to the original trade (it may only be partially rolled). The price is also likely different as market conditions may have evolved.
    
    Parameters 
    ----------
    businessEvent : BusinessEvent
    
    Returns
    -------
    is_event : boolean
    
    """
    self = inspect.currentframe()
    
    
    beforeEconomicterms = _resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(get_only_element(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "businessEvent"), "instruction")), "before"), "trade"), "tradableProduct"), "product"), "contractualProduct"), "economicTerms")
    openEconomicTerms = _resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(get_only_element(FilterOpenTradeStates(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "businessEvent"), "after"))), "trade"), "tradableProduct"), "product"), "contractualProduct"), "economicTerms")
    closedTradeState = FilterClosedTradeStates(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "businessEvent"), "after"))
    is_event =  ((((((rosetta_attr_exists(_resolve_rosetta_attr(self, "beforeEconomicterms")) and rosetta_attr_exists(_resolve_rosetta_attr(self, "openEconomicTerms"))) and all_elements(rosetta_count(_resolve_rosetta_attr(self, "closedTradeState")), "=", 1)) and all_elements(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "openEconomicTerms"), "payout"), "=", _resolve_rosetta_attr(_resolve_rosetta_attr(self, "beforeEconomicterms"), "payout"))) and all_elements(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "openEconomicTerms"), "collateral"), "=", _resolve_rosetta_attr(_resolve_rosetta_attr(self, "beforeEconomicterms"), "collateral"))) and all_elements(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "openEconomicTerms"), "effectiveDate"), "=", _resolve_rosetta_attr(_resolve_rosetta_attr(self, "beforeEconomicterms"), "terminationDate"))) and any_elements(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "openEconomicTerms"), "terminationDate"), "<>", _resolve_rosetta_attr(_resolve_rosetta_attr(self, "beforeEconomicterms"), "terminationDate")))
    
    
    return is_event

sys.modules[__name__].__class__ = create_module_attr_guardian(sys.modules[__name__].__class__)

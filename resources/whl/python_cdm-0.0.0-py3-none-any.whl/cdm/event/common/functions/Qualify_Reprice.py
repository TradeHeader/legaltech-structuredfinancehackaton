# pylint: disable=line-too-long, invalid-name, missing-function-docstring, missing-module-docstring, superfluous-parens
# pylint: disable=wrong-import-position, unused-import, unused-wildcard-import, wildcard-import, wrong-import-order, missing-class-docstring
from __future__ import annotations
import sys
import datetime
import inspect
from decimal import Decimal
from abc import ABC, abstractmethod
from rosetta.runtime.utils import *
from rosetta.runtime.func_proxy import replaceable, create_module_attr_guardian
from cdm.event.common.BusinessEvent import BusinessEvent
from cdm.event.common.functions.ExtractTradePurchasePrice import ExtractTradePurchasePrice
from cdm.event.common.functions.ExtractTradeCollateralPrice import ExtractTradeCollateralPrice

__all__ = ['Qualify_Reprice']



@replaceable
@qualification_func
def Qualify_Reprice(businessEvent: BusinessEvent) -> bool:
    """
    This qualification function is used to qualify repricing of a contractual product with an interest rate payout and assetPayout.
    
    Parameters 
    ----------
    businessEvent : BusinessEvent
    
    Returns
    -------
    is_event : boolean
    
    """
    self = inspect.currentframe()
    
    
    openTrades = _resolve_rosetta_attr(FilterOpenTradeStates(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "businessEvent"), "after")), "trade")
    closedTradeState = FilterClosedTradeStates(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "businessEvent"), "after"))
    beforeTradableProduct = ExtractBeforeTradableProduct(_resolve_rosetta_attr(self, "businessEvent"))
    afterTradableProduct = ExtractAfterTradableProduct(_resolve_rosetta_attr(self, "businessEvent"))
    beforeTradePurchasePrice = ExtractTradePurchasePrice(_resolve_rosetta_attr(self, "beforeTradableProduct"))
    afterTradePurchasePrice = ExtractTradePurchasePrice(_resolve_rosetta_attr(self, "afterTradableProduct"))
    beforeTradeCollateralQuantity = ExtractTradeCollateralQuantity(_resolve_rosetta_attr(self, "beforeTradableProduct"))
    afterTradeCollateralQuantity = ExtractTradeCollateralQuantity(_resolve_rosetta_attr(self, "afterTradableProduct"))
    beforeTradeCollateralPrice = ExtractTradeCollateralPrice(_resolve_rosetta_attr(self, "beforeTradableProduct"))
    afterTradeCollateralPrice = ExtractTradeCollateralPrice(_resolve_rosetta_attr(self, "afterTradableProduct"))
    beforeEconomicterms = ExtractBeforeEconomicTerms(_resolve_rosetta_attr(self, "businessEvent"))
    openEconomicTerms = ExtractOpenEconomicTerms(_resolve_rosetta_attr(self, "businessEvent"))
    is_event =  ((((((((((rosetta_attr_exists(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "businessEvent"), "after"), "trade"), "tradableProduct"), "product"), "contractualProduct"), "economicTerms"), "payout"), "interestRatePayout")) and all_elements(rosetta_count(_resolve_rosetta_attr(self, "openTrades")), "=", 1)) and all_elements(rosetta_count(_resolve_rosetta_attr(self, "closedTradeState")), "=", 1)) and rosetta_attr_exists(_resolve_rosetta_attr(self, "beforeTradePurchasePrice"))) and rosetta_attr_exists(_resolve_rosetta_attr(self, "afterTradePurchasePrice"))) and any_elements(_resolve_rosetta_attr(self, "afterTradePurchasePrice"), "<>", _resolve_rosetta_attr(self, "beforeTradePurchasePrice"))) and all_elements(_resolve_rosetta_attr(self, "beforeTradeCollateralQuantity"), "=", _resolve_rosetta_attr(self, "afterTradeCollateralQuantity"))) and any_elements(_resolve_rosetta_attr(self, "beforeTradeCollateralPrice"), "<>", _resolve_rosetta_attr(self, "afterTradeCollateralPrice"))) and rosetta_attr_exists(_resolve_rosetta_attr(self, "beforeEconomicterms"))) and rosetta_attr_exists(_resolve_rosetta_attr(self, "openEconomicTerms"))) and all_elements(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "openEconomicTerms"), "terminationDate"), "=", _resolve_rosetta_attr(_resolve_rosetta_attr(self, "beforeEconomicterms"), "terminationDate")))
    
    
    return is_event

sys.modules[__name__].__class__ = create_module_attr_guardian(sys.modules[__name__].__class__)

# pylint: disable=line-too-long, invalid-name, missing-function-docstring, missing-module-docstring, superfluous-parens
# pylint: disable=wrong-import-position, unused-import, unused-wildcard-import, wildcard-import, wrong-import-order, missing-class-docstring
from __future__ import annotations
import sys
import datetime
import inspect
from decimal import Decimal
from abc import ABC, abstractmethod
from rosetta.runtime.utils import *
from rosetta.runtime.func_proxy import replaceable, create_module_attr_guardian
from cdm.event.common.BusinessEvent import BusinessEvent

__all__ = ['Qualify_OnDemandPayment']



@replaceable
@qualification_func
def Qualify_OnDemandPayment(businessEvent: BusinessEvent) -> bool:
    """
    Qualification of a on-demand payment.
    
    Parameters 
    ----------
    businessEvent : BusinessEvent
    
    Returns
    -------
    is_event : boolean
    
    """
    self = inspect.currentframe()
    
    
    afterTradeStates = FilterOpenTradeStates(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "businessEvent"), "after"))
    beforeCashFlow = _resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(get_only_element(FilterClosedTradeStates(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "businessEvent"), "after"))), "trade"), "tradableProduct"), "product"), "contractualProduct"), "economicTerms"), "payout"), "cashflow")
    afterCashFlow = _resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(get_only_element(FilterOpenTradeStates(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "businessEvent"), "after"))), "trade"), "tradableProduct"), "product"), "contractualProduct"), "economicTerms"), "payout"), "cashflow")
    is_event =  (((((all_elements(rosetta_count(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "businessEvent"), "instruction"), "before")), "=", 1) and all_elements(rosetta_count(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "businessEvent"), "after")), "=", 1)) and all_elements(rosetta_count(_resolve_rosetta_attr(self, "afterTradeStates")), "=", 1)) and self.check_one_of_constraint(self, _resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "businessEvent"), "instruction"), "primitiveInstruction"), "termsChange"))) and all_elements(rosetta_count(_resolve_rosetta_attr(self, "afterCashFlow")), ">", rosetta_count(_resolve_rosetta_attr(self, "beforeCashFlow")))) and all_elements(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "afterCashFlow"), "cashflowType"), "cashflowType"), "=", _resolve_rosetta_attr(ScheduledTransferEnum, "NET_INTEREST")))
    
    
    return is_event

sys.modules[__name__].__class__ = create_module_attr_guardian(sys.modules[__name__].__class__)

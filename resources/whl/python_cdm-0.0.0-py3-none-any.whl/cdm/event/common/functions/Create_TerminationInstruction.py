# pylint: disable=line-too-long, invalid-name, missing-function-docstring, missing-module-docstring, superfluous-parens
# pylint: disable=wrong-import-position, unused-import, unused-wildcard-import, wildcard-import, wrong-import-order, missing-class-docstring
from __future__ import annotations
import sys
import datetime
import inspect
from decimal import Decimal
from abc import ABC, abstractmethod
from rosetta.runtime.utils import *
from rosetta.runtime.func_proxy import replaceable, create_module_attr_guardian
from cdm.product.common.settlement.PriceQuantity import PriceQuantity
from cdm.event.common.QuantityChangeInstruction import QuantityChangeInstruction
from cdm.event.common.TradeState import TradeState
from cdm.event.common.PrimitiveInstruction import PrimitiveInstruction
from cdm.base.math.NonNegativeQuantitySchedule import NonNegativeQuantitySchedule

__all__ = ['Create_TerminationInstruction']



@replaceable
def Create_TerminationInstruction(tradeState: TradeState) -> PrimitiveInstruction:
    """
    Creates the relevant primitive instruction for a termination, which consists in a quantity change to bring the quantity to zero.
    
    Parameters 
    ----------
    tradeState : TradeState
    The original trade to be termintaed.
    
    Returns
    -------
    instruction : PrimitiveInstruction
    
    """
    self = inspect.currentframe()
    
    
    changeQuantity = (lambda item: set(item))(map(lambda item: NonNegativeQuantitySchedule(value=0.0, unit=_resolve_rosetta_attr(item, "unit")), _resolve_rosetta_attr(_resolve_rosetta_attr(get_only_element(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "tradeState"), "trade"), "tradableProduct"), "tradeLot")), "priceQuantity"), "quantity")))
    changePriceQuantity = PriceQuantity(quantity=_resolve_rosetta_attr(self, "changeQuantity"))
    instruction = _get_rosetta_object('PrimitiveInstruction', 'quantityChange', QuantityChangeInstruction(change=_resolve_rosetta_attr(self, "changePriceQuantity"), direction=_resolve_rosetta_attr(QuantityChangeDirectionEnum, "REPLACE"), lotIdentifier=[]))
    
    
    return instruction

sys.modules[__name__].__class__ = create_module_attr_guardian(sys.modules[__name__].__class__)

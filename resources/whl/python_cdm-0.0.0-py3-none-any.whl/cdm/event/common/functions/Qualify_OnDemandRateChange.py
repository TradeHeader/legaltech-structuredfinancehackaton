# pylint: disable=line-too-long, invalid-name, missing-function-docstring, missing-module-docstring, superfluous-parens
# pylint: disable=wrong-import-position, unused-import, unused-wildcard-import, wildcard-import, wrong-import-order, missing-class-docstring
from __future__ import annotations
import sys
import datetime
import inspect
from decimal import Decimal
from abc import ABC, abstractmethod
from rosetta.runtime.utils import *
from rosetta.runtime.func_proxy import replaceable, create_module_attr_guardian
from cdm.event.common.BusinessEvent import BusinessEvent
from cdm.product.common.settlement.PriceQuantity import PriceQuantity

__all__ = ['Qualify_OnDemandRateChange']



@replaceable
@qualification_func
def Qualify_OnDemandRateChange(businessEvent: BusinessEvent) -> bool:
    """
    The qualification of on an-demand rate change event from the fact that the only primitive is the reset.
    
    Parameters 
    ----------
    businessEvent : BusinessEvent
    
    Returns
    -------
    is_event : boolean
    
    """
    self = inspect.currentframe()
    
    
    beforeTradableProduct = _resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(get_only_element(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "businessEvent"), "instruction")), "before"), "trade"), "tradableProduct")
    beforeEconomicterms = _resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "beforeTradableProduct"), "product"), "contractualProduct"), "economicTerms")
    openTradableProduct = _resolve_rosetta_attr(_resolve_rosetta_attr(get_only_element(FilterOpenTradeStates(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "businessEvent"), "after"))), "trade"), "tradableProduct")
    openEconomicTerms = _resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "openTradableProduct"), "product"), "contractualProduct"), "economicTerms")
    closedTradeState = FilterClosedTradeStates(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "businessEvent"), "after"))
    beforePriceQuantityRateOnly = (lambda item: map(lambda item: _resolve_rosetta_attr(self, "value"), item))((lambda item: rosetta_filter(item, lambda item: all_elements(_resolve_rosetta_attr(self, "priceType"), "=", _resolve_rosetta_attr(PriceTypeEnum, "INTEREST_RATE"))))((lambda item: flatten_list(item))(map(lambda item: _resolve_rosetta_attr(self, "price"), _resolve_rosetta_attr(get_only_element(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "beforeTradableProduct"), "tradeLot")), "priceQuantity")))))
    openPriceQuantityRateOnly = (lambda item: map(lambda item: _resolve_rosetta_attr(self, "value"), item))((lambda item: rosetta_filter(item, lambda item: all_elements(_resolve_rosetta_attr(self, "priceType"), "=", _resolve_rosetta_attr(PriceTypeEnum, "INTEREST_RATE"))))((lambda item: flatten_list(item))(map(lambda item: _resolve_rosetta_attr(self, "price"), _resolve_rosetta_attr(get_only_element(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "openTradableProduct"), "tradeLot")), "priceQuantity")))))
    beforePriceQuantityNoRate = map(lambda item: PriceQuantity(price=rosetta_filter(_resolve_rosetta_attr(self, "price"), lambda item: any_elements(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "p"), "priceType"), "<>", _resolve_rosetta_attr(PriceTypeEnum, "INTEREST_RATE"))), quantity=_resolve_rosetta_attr(self, "quantity"), observable=_resolve_rosetta_attr(self, "observable")), _resolve_rosetta_attr(get_only_element(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "beforeTradableProduct"), "tradeLot")), "priceQuantity"))
    openPriceQuantityNoRate = map(lambda item: PriceQuantity(price=rosetta_filter(_resolve_rosetta_attr(self, "price"), lambda item: any_elements(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "p"), "priceType"), "<>", _resolve_rosetta_attr(PriceTypeEnum, "INTEREST_RATE"))), quantity=_resolve_rosetta_attr(self, "quantity"), observable=_resolve_rosetta_attr(self, "observable")), _resolve_rosetta_attr(get_only_element(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "openTradableProduct"), "tradeLot")), "priceQuantity"))
    is_event =  (((((((rosetta_attr_exists(_resolve_rosetta_attr(self, "beforeEconomicterms")) and rosetta_attr_exists(_resolve_rosetta_attr(self, "openEconomicTerms"))) and all_elements(rosetta_count(_resolve_rosetta_attr(self, "closedTradeState")), "=", 1)) and all_elements(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "openEconomicTerms"), "collateral"), "=", _resolve_rosetta_attr(_resolve_rosetta_attr(self, "beforeEconomicterms"), "collateral"))) and all_elements(rosetta_count(_resolve_rosetta_attr(self, "beforePriceQuantityRateOnly")), "=", 1)) and all_elements(rosetta_count(_resolve_rosetta_attr(self, "openPriceQuantityRateOnly")), "=", 1)) and any_elements(get_only_element(_resolve_rosetta_attr(self, "beforePriceQuantityRateOnly")), "<>", get_only_element(_resolve_rosetta_attr(self, "openPriceQuantityRateOnly")))) and all_elements(_resolve_rosetta_attr(self, "beforePriceQuantityNoRate"), "=", _resolve_rosetta_attr(self, "openPriceQuantityNoRate")))
    
    
    return is_event

sys.modules[__name__].__class__ = create_module_attr_guardian(sys.modules[__name__].__class__)

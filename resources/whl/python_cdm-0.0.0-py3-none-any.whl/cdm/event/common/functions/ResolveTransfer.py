# pylint: disable=line-too-long, invalid-name, missing-function-docstring, missing-module-docstring, superfluous-parens
# pylint: disable=wrong-import-position, unused-import, unused-wildcard-import, wildcard-import, wrong-import-order, missing-class-docstring
from __future__ import annotations
import sys
import datetime
import inspect
from decimal import Decimal
from abc import ABC, abstractmethod
from rosetta.runtime.utils import *
from rosetta.runtime.func_proxy import replaceable, create_module_attr_guardian
from cdm.event.common.Transfer import Transfer
from cdm.event.common.functions.EquityCashSettlementAmount import EquityCashSettlementAmount
from cdm.event.common.functions.SecurityFinanceCashSettlementAmount import SecurityFinanceCashSettlementAmount
from cdm.event.common.functions.InterestCashSettlementAmount import InterestCashSettlementAmount
from cdm.event.common.CalculateTransferInstruction import CalculateTransferInstruction

__all__ = ['ResolveTransfer']



@replaceable
def ResolveTransfer(instruction: CalculateTransferInstruction) -> Transfer:
    """
    Defines how to calculate the amount due to be transferred after a Reset Event.
    
    Parameters 
    ----------
    instruction : CalculateTransferInstruction
    
    Returns
    -------
    transfer : Transfer
    
    """
    self = inspect.currentframe()
    
    
    def _then_fn2():
        return InterestCashSettlementAmount(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "instruction"), "tradeState"), get_only_element(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "payout"), "interestRatePayout")), _resolve_rosetta_attr(_resolve_rosetta_attr(self, "instruction"), "resets"), _resolve_rosetta_attr(_resolve_rosetta_attr(self, "instruction"), "date"))
    
    def _else_fn2():
        return True
    
    def _then_fn1():
        return EquityCashSettlementAmount(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "instruction"), "tradeState"), _resolve_rosetta_attr(_resolve_rosetta_attr(self, "instruction"), "date"))
    
    def _else_fn1():
        return if_cond_fn((rosetta_attr_exists(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "payout"), "interestRatePayout"), "rateSpecification"), "floatingRate")) or rosetta_attr_exists(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "payout"), "interestRatePayout"), "rateSpecification"), "fixedRate"))), _then_fn2, _else_fn2)
    
    def _then_fn0():
        return SecurityFinanceCashSettlementAmount(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "instruction"), "tradeState"), _resolve_rosetta_attr(_resolve_rosetta_attr(self, "instruction"), "date"), _resolve_rosetta_attr(_resolve_rosetta_attr(self, "instruction"), "quantity"), _resolve_rosetta_attr(_resolve_rosetta_attr(self, "instruction"), "payerReceiver"))
    
    def _else_fn0():
        return if_cond_fn(rosetta_attr_exists(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "payout"), "performancePayout")), _then_fn1, _else_fn1)
    
    payout = _resolve_rosetta_attr(_resolve_rosetta_attr(self, "instruction"), "payout")
    transfer =  if_cond_fn(rosetta_attr_exists(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "payout"), "assetPayout")), _then_fn0, _else_fn0)
    transfer = _get_rosetta_object('Transfer', 'settlementDate', _get_rosetta_object('AdjustableOrAdjustedOrRelativeDate', 'adjustedDate', _resolve_rosetta_attr(_resolve_rosetta_attr(self, "instruction"), "date")))
    
    
    return transfer

sys.modules[__name__].__class__ = create_module_attr_guardian(sys.modules[__name__].__class__)

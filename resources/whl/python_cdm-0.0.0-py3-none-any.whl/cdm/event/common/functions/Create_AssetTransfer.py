# pylint: disable=line-too-long, invalid-name, missing-function-docstring, missing-module-docstring, superfluous-parens
# pylint: disable=wrong-import-position, unused-import, unused-wildcard-import, wildcard-import, wrong-import-order, missing-class-docstring
from __future__ import annotations
import sys
import datetime
import inspect
from decimal import Decimal
from abc import ABC, abstractmethod
from rosetta.runtime.utils import *
from rosetta.runtime.func_proxy import replaceable, create_module_attr_guardian
from cdm.base.math.NonNegativeQuantity import NonNegativeQuantity
from cdm.event.common.Transfer import Transfer
from cdm.observable.asset.PriceTypeEnum import PriceTypeEnum
from cdm.observable.asset.functions.FilterPrice import FilterPrice
from cdm.event.common.CalculateTransferInstruction import CalculateTransferInstruction

__all__ = ['Create_AssetTransfer']



@replaceable
def Create_AssetTransfer(instruction: CalculateTransferInstruction) -> Transfer:
    """
    Defines how Transfer that represents an exchange of asset based on an asset payout, should be constructed.
    
    Parameters 
    ----------
    instruction : CalculateTransferInstruction
    
    Returns
    -------
    transfer : Transfer
    
    """
    _pre_registry = {}
    self = inspect.currentframe()
    
    # conditions
    
    @rosetta_local_condition(_pre_registry)
    def condition_0_ShareUnits(self):
        def _then_fn0():
            return all_elements(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "instruction"), "quantity"), "unit"), "financialUnit"), "=", _resolve_rosetta_attr(FinancialUnitEnum, "SHARE"))
        
        def _else_fn0():
            return True
        
        return if_cond_fn(rosetta_attr_exists(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "instruction"), "quantity")), _then_fn0, _else_fn0)
    # Execute all registered conditions
    execute_local_conditions(_pre_registry, 'Pre-condition')
    
    def _then_fn0():
        return _resolve_rosetta_attr(_resolve_rosetta_attr(self, "instruction"), "quantity")
    
    def _else_fn0():
        return NonNegativeQuantity(value=_resolve_rosetta_attr(_resolve_rosetta_attr(self, "tradeQuantity"), "value"), unit=_resolve_rosetta_attr(_resolve_rosetta_attr(self, "tradeQuantity"), "unit"))
    
    def _then_fn2():
        return _resolve_rosetta_attr(ExtractCounterpartyByRole(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "instruction"), "tradeState"), "trade"), "tradableProduct"), "counterparty"), _resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "assetPayout"), "payerReceiver"), "payer")), "partyReference")
    
    def _else_fn2():
        return True
    
    def _then_fn1():
        return _resolve_rosetta_attr(ExtractCounterpartyByRole(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "instruction"), "tradeState"), "trade"), "tradableProduct"), "counterparty"), _resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "instruction"), "payerReceiver"), "payer")), "partyReference")
    
    def _else_fn1():
        return if_cond_fn(rosetta_attr_exists(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "assetPayout"), "payerReceiver"), "payer")), _then_fn2, _else_fn2)
    
    def _then_fn3():
        return _resolve_rosetta_attr(ExtractCounterpartyByRole(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "instruction"), "tradeState"), "trade"), "tradableProduct"), "counterparty"), _resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "assetPayout"), "payerReceiver"), "receiver")), "partyReference")
    
    def _else_fn3():
        return True
    
    def _then_fn2():
        return _resolve_rosetta_attr(ExtractCounterpartyByRole(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "instruction"), "tradeState"), "trade"), "tradableProduct"), "counterparty"), _resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "instruction"), "payerReceiver"), "receiver")), "partyReference")
    
    def _else_fn2():
        return if_cond_fn(rosetta_attr_exists(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "assetPayout"), "payerReceiver"), "receiver")), _then_fn3, _else_fn3)
    
    def _then_fn3():
        return get_only_element(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "instruction"), "tradeState"), "trade"), "tradableProduct"), "product"), "contractualProduct"), "economicTerms"), "collateral"), "collateralPortfolio"), "collateralPosition"), "product"), "contractualProduct"), "economicTerms"), "payout"), "assetPayout"))
    
    def _else_fn3():
        return True
    
    assetPayout = get_only_element(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "instruction"), "tradeState"), "trade"), "tradableProduct"), "product"), "contractualProduct"), "economicTerms"), "collateral"), "collateralPortfolio"), "collateralPosition"), "product"), "contractualProduct"), "economicTerms"), "payout"), "assetPayout"))
    tradeQuantity = get_only_element(FilterQuantityByFinancialUnit(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "instruction"), "tradeState"), "trade"), "tradableProduct"), "tradeLot"), "priceQuantity"), "quantity"), _resolve_rosetta_attr(FinancialUnitEnum, "SHARE")))
    securityQuantity = if_cond_fn(rosetta_attr_exists(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "instruction"), "quantity")), _then_fn0, _else_fn0)
    securityPrice = FilterPrice(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "instruction"), "tradeState"), "trade"), "tradableProduct"), "tradeLot"), "priceQuantity"), "price"), _resolve_rosetta_attr(PriceTypeEnum, "ASSET_PRICE"), [], [])
    transfer = _get_rosetta_object('Transfer', 'quantity', NonNegativeQuantity(value=_resolve_rosetta_attr(_resolve_rosetta_attr(self, "securityQuantity"), "value"), unit=_resolve_rosetta_attr(_resolve_rosetta_attr(self, "securityQuantity"), "unit")))
    transfer.add_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, transfer), 'observable'), 'productIdentifier'), _resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "assetPayout"), "securityInformation"), "security"), "productIdentifier"))
    transfer = set_rosetta_attr(_resolve_rosetta_attr(self, 'transfer'), 'payerReceiver->payerPartyReference', if_cond_fn(rosetta_attr_exists(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "instruction"), "payerReceiver"), "payer")), _then_fn0, _else_fn0))
    transfer = set_rosetta_attr(_resolve_rosetta_attr(self, 'transfer'), 'payerReceiver->receiverPartyReference', if_cond_fn(rosetta_attr_exists(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "instruction"), "payerReceiver"), "payer")), _then_fn1, _else_fn1))
    transfer = set_rosetta_attr(_resolve_rosetta_attr(self, 'transfer'), 'settlementDate->adjustedDate', _resolve_rosetta_attr(_resolve_rosetta_attr(self, "instruction"), "date"))
    transfer = set_rosetta_attr(_resolve_rosetta_attr(self, 'transfer'), 'settlementOrigin->assetPayout', {if_cond_fn(rosetta_attr_exists(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "instruction"), "tradeState"), "trade"), "tradableProduct"), "product"), "contractualProduct"), "economicTerms"), "collateral"), "collateralPortfolio"), "collateralPosition"), "product"), "contractualProduct"), "economicTerms"), "payout"), "assetPayout")), _then_fn3, _else_fn3): True})
    
    
    return transfer

sys.modules[__name__].__class__ = create_module_attr_guardian(sys.modules[__name__].__class__)

# pylint: disable=line-too-long, invalid-name, missing-function-docstring, missing-module-docstring, superfluous-parens
# pylint: disable=wrong-import-position, unused-import, unused-wildcard-import, wildcard-import, wrong-import-order, missing-class-docstring
from __future__ import annotations
import sys
import datetime
import inspect
from decimal import Decimal
from abc import ABC, abstractmethod
from rosetta.runtime.utils import *
from rosetta.runtime.func_proxy import replaceable, create_module_attr_guardian
from cdm.event.common.BusinessEvent import BusinessEvent
from cdm.event.common.functions.FilterCashTransfers import FilterCashTransfers
from cdm.event.common.functions.FilterSecurityTransfers import FilterSecurityTransfers

__all__ = ['Qualify_SecuritySettlement']



@replaceable
@qualification_func
def Qualify_SecuritySettlement(businessEvent: BusinessEvent) -> bool:
    """
    The qualification of a security settlement from the fact that (i) it is composed of a cashTransfer component and a securityTransfer component, and (ii) the cash and security move in opposite directions.
    
    Parameters 
    ----------
    businessEvent : BusinessEvent
    
    Returns
    -------
    is_event : boolean
    
    """
    self = inspect.currentframe()
    
    
    transfers = TransfersForDate(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "businessEvent"), "after"), "transferHistory"), "transfer"), _resolve_rosetta_attr(_resolve_rosetta_attr(self, "businessEvent"), "eventDate"))
    is_event =  ((self.check_one_of_constraint(self, _resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "transfers"), "observable"), "productIdentifier")) and self.check_one_of_constraint(self, _resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "transfers"), "quantity"), "unit"), "currency"))) and all_elements(_resolve_rosetta_attr(_resolve_rosetta_attr(get_only_element(FilterCashTransfers(_resolve_rosetta_attr(self, "transfers"))), "payerReceiver"), "payerPartyReference"), "=", _resolve_rosetta_attr(_resolve_rosetta_attr(get_only_element(FilterSecurityTransfers(_resolve_rosetta_attr(self, "transfers"))), "payerReceiver"), "receiverPartyReference")))
    
    
    return is_event

sys.modules[__name__].__class__ = create_module_attr_guardian(sys.modules[__name__].__class__)

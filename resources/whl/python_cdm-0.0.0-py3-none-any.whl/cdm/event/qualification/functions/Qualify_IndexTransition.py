# pylint: disable=line-too-long, invalid-name, missing-function-docstring, missing-module-docstring, superfluous-parens
# pylint: disable=wrong-import-position, unused-import, unused-wildcard-import, wildcard-import, wrong-import-order, missing-class-docstring
from __future__ import annotations
import sys
import datetime
import inspect
from decimal import Decimal
from abc import ABC, abstractmethod
from rosetta.runtime.utils import *
from rosetta.runtime.func_proxy import replaceable, create_module_attr_guardian
from cdm.event.common.BusinessEvent import BusinessEvent

__all__ = ['Qualify_IndexTransition']



@replaceable
@qualification_func
def Qualify_IndexTransition(businessEvent: BusinessEvent) -> bool:
    """
    The qualification of an index transition event based on (i) adjustment spread applied and (ii) floating rate index changed.
    
    Parameters 
    ----------
    businessEvent : BusinessEvent
    
    Returns
    -------
    is_event : boolean
    
    """
    self = inspect.currentframe()
    
    
    def _then_fn0():
        return any_elements(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "spread"), "value"), "<>", 0)
    
    def _else_fn0():
        return False
    
    after = _resolve_rosetta_attr(_resolve_rosetta_attr(get_only_element(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "businessEvent"), "after")), "trade"), "tradableProduct")
    before = _resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "businessEvent"), "instruction"), "before"), "trade"), "tradableProduct")
    floatingRateIndexChanged = (rosetta_attr_exists(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "before"), "tradeLot"), "priceQuantity"), "observable"), "rateOption"), "floatingRateIndex")) and disjoint(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "before"), "tradeLot"), "priceQuantity"), "observable"), "rateOption"), "floatingRateIndex"), _resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "after"), "tradeLot"), "priceQuantity"), "observable"), "rateOption"), "floatingRateIndex")))
    spread = FilterPrice(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "after"), "tradeLot"), "priceQuantity"), "price"), _resolve_rosetta_attr(PriceTypeEnum, "INTEREST_RATE"), [_resolve_rosetta_attr(ArithmeticOperationEnum, "ADD"), _resolve_rosetta_attr(ArithmeticOperationEnum, "SUBTRACT")], [])
    adjustmentSpreadAdded = if_cond_fn(rosetta_attr_exists(_resolve_rosetta_attr(self, "spread")), _then_fn0, _else_fn0)
    is_event =  ((all_elements(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "businessEvent"), "intent"), "=", _resolve_rosetta_attr(EventIntentEnum, "INDEX_TRANSITION")) and all_elements(_resolve_rosetta_attr(self, "floatingRateIndexChanged"), "=", False)) and all_elements(_resolve_rosetta_attr(self, "adjustmentSpreadAdded"), "=", False))
    
    
    return is_event

sys.modules[__name__].__class__ = create_module_attr_guardian(sys.modules[__name__].__class__)

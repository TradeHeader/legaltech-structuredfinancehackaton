# pylint: disable=line-too-long, invalid-name, missing-function-docstring, missing-module-docstring, superfluous-parens
# pylint: disable=wrong-import-position, unused-import, unused-wildcard-import, wildcard-import, wrong-import-order, missing-class-docstring
from __future__ import annotations
import sys
import datetime
import inspect
from decimal import Decimal
from abc import ABC, abstractmethod
from rosetta.runtime.utils import *
from rosetta.runtime.func_proxy import replaceable, create_module_attr_guardian
from cdm.event.common.BusinessEvent import BusinessEvent

__all__ = ['Qualify_Allocation']



@replaceable
@qualification_func
def Qualify_Allocation(businessEvent: BusinessEvent) -> bool:
    """
    The qualification of allocation event from the fact that (i) the only primitives are split and contract formation (ii) the number of split executions and the number of contract formations are equal.  Note that SplitPrimitive type has a condition to check that the post-split quantities sum to the pre-split quantity.  Also note that it is expected that an allocation can result in a single contract.
    
    Parameters 
    ----------
    businessEvent : BusinessEvent
    
    Returns
    -------
    is_event : boolean
    
    """
    self = inspect.currentframe()
    
    
    beforeTradeState = get_only_element(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "businessEvent"), "instruction"), "before"))
    closedTradeStates = FilterClosedTradeStates(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "businessEvent"), "after"))
    openTradeStates = FilterOpenTradeStates(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "businessEvent"), "after"))
    is_event =  (((((all_elements(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "businessEvent"), "intent"), "=", _resolve_rosetta_attr(EventIntentEnum, "ALLOCATION")) and all_elements(rosetta_count(_resolve_rosetta_attr(self, "closedTradeStates")), "=", 1)) and all_elements(rosetta_count(_resolve_rosetta_attr(self, "openTradeStates")), ">=", 1)) and rosetta_attr_exists(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "businessEvent"), "instruction"), "primitiveInstruction"), "split"))) and all_elements(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "beforeTradeState"), "trade"), "tradableProduct"), "counterparty"), "partyReference"), "=", _resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(get_only_element(_resolve_rosetta_attr(self, "closedTradeStates")), "trade"), "tradableProduct"), "counterparty"), "partyReference"))) and all_elements(map(lambda item: any_elements(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(item, "trade"), "tradableProduct"), "counterparty"), "partyReference"), "<>", _resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "beforeTradeState"), "trade"), "tradableProduct"), "counterparty"), "partyReference")), _resolve_rosetta_attr(self, "openTradeStates")), "=", False))
    
    
    return is_event

sys.modules[__name__].__class__ = create_module_attr_guardian(sys.modules[__name__].__class__)

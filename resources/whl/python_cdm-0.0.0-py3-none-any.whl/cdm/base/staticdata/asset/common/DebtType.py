# pylint: disable=line-too-long, invalid-name, missing-function-docstring
# pylint: disable=bad-indentation, trailing-whitespace, superfluous-parens
# pylint: disable=wrong-import-position, unused-import, unused-wildcard-import
# pylint: disable=wildcard-import, wrong-import-order, missing-class-docstring
# pylint: disable=missing-module-docstring
from __future__ import annotations
from typing import List, Optional
import datetime
import inspect
from decimal import Decimal
from pydantic import Field
from rosetta.runtime.utils import (
    BaseDataClass, rosetta_condition, _resolve_rosetta_attr
)
from rosetta.runtime.utils import *

__all__ = ['DebtType']


class DebtType(BaseDataClass):
  """
  Specifies the type of debt instrument.
  """
  
  debtClass: Optional[cdm.base.staticdata.asset.common.DebtClassEnum.DebtClassEnum] = Field(None, description="Specifies the characteristics of a debt instrument.")
  
  """
  Specifies the characteristics of a debt instrument.
  """
  
  debtEconomics: List[cdm.base.staticdata.asset.common.DebtEconomics.DebtEconomics] = Field([], description="Specifies selected financial terms of a debt instrument.")
  
  """
  Specifies selected financial terms of a debt instrument.
  """

import cdm 
import cdm.base.staticdata.asset.common.DebtClassEnum
import cdm.base.staticdata.asset.common.DebtEconomics

# pylint: disable=line-too-long, invalid-name, missing-function-docstring
# pylint: disable=bad-indentation, trailing-whitespace, superfluous-parens
# pylint: disable=wrong-import-position, unused-import, unused-wildcard-import
# pylint: disable=wildcard-import, wrong-import-order, missing-class-docstring
# pylint: disable=missing-module-docstring
from __future__ import annotations
from typing import List, Optional
import datetime
import inspect
from decimal import Decimal
from pydantic import Field
from rosetta.runtime.utils import (
    BaseDataClass, rosetta_condition, _resolve_rosetta_attr
)
from rosetta.runtime.utils import *

__all__ = ['IndexReferenceInformation']


class IndexReferenceInformation(BaseDataClass):
  """
  A class defining information related to Index
  """
  
  indexName: Optional[AttributeWithScheme[str] | str] = Field(None, description="The name of the index expressed as a free format string with an associated scheme.")
  
  """
  The name of the index expressed as a free format string with an associated scheme.
  """
  
  indexId: List[AttributeWithScheme[str] | str] = Field([], description="An index identifier (e.g. RED pair code).")
  
  """
  An index identifier (e.g. RED pair code).
  """
  
  @rosetta_condition
  def condition_0_IndexAttributes(self):
      """
      A required choice condition for either a floating rate or inflation rate index.
      """
      item = self
      return (rosetta_attr_exists(_resolve_rosetta_attr(self, "indexName")) or rosetta_attr_exists(_resolve_rosetta_attr(self, "indexId")))

import cdm 

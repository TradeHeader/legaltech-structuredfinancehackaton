# pylint: disable=missing-module-docstring, invalid-name, line-too-long
from enum import Enum

__all__ = ['RoundingModeEnum']

class RoundingModeEnum(Enum):
    DOWN = "Down"
    UP = "Up"
